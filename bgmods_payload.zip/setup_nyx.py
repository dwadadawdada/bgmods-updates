"""Configura NYX automaticamente apos INSTALAR_TUDO.bat ou NYX.bat unico."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
NYX_ROOT = APP_DIR.parent if APP_DIR.name.lower() == "app" else APP_DIR
CONFIG_FILE = APP_DIR / "config.json"
BRIDGE_DIR = APP_DIR / "cheatengine-mcp-bridge"
BRIDGE_ZIP_URL = "https://github.com/miscusi-peek/cheatengine-mcp-bridge/archive/refs/heads/main.zip"
CE_TABLE_FILE = APP_DIR / "NYX_CE_BRIDGE.ct"
CE_INSTALLER_URL = "https://github.com/cheat-engine/cheat-engine/releases/download/7.5/CheatEngine75.exe"
CE_INSTALLER_FALLBACK = "https://d2oq4dwfbh6gxl.cloudfront.net/f/CheatEngine/1032/CheatEngine75.exe"

DEFAULT_CONFIG = {
    "provider": "ollama",
    "ollama_url": "http://localhost:11434",
    "ollama_model": "huihui_ai/qwen3-abliterated:14b",
    "intelligence_max": True,
    "max_history": 64,
    "ollama_vision_model": "llava:7b",
    "api_url": "https://api.openai.com/v1/chat/completions",
    "api_key": "",
    "api_model": "gpt-4o-mini",
    "anthropic_url": "https://api.anthropic.com/v1/messages",
    "anthropic_key": "",
    "anthropic_model": "claude-opus-4-8",
    "assistant_name": "BG MODS IA",
    "agent_mode": True,
    "agent_show_trace": True,
    "ce_mcp_enabled": True,
    "ce_mcp_script": "",
}


def load_config() -> dict:
    if CONFIG_FILE.is_file():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return {**DEFAULT_CONFIG, **data}
        except json.JSONDecodeError:
            pass
    return DEFAULT_CONFIG.copy()


def save_config(config: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def ensure_user_data_dirs() -> None:
    root = Path(__import__("os").environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "NYX"
    (root / "sessions").mkdir(parents=True, exist_ok=True)
    (root / "workspace").mkdir(parents=True, exist_ok=True)


def download_bridge() -> Path:
    script = BRIDGE_DIR / "MCP_Server" / "mcp_cheatengine.py"
    if script.is_file():
        return script

    print("[setup] baixando cheatengine-mcp-bridge...")
    BRIDGE_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = APP_DIR / "ce-mcp-bridge-main.zip"

    req = urllib.request.Request(BRIDGE_ZIP_URL, headers={"User-Agent": "NYX-Setup"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        zip_path.write_bytes(resp.read())

    extract_root = APP_DIR / "_ce_bridge_extract"
    if extract_root.exists():
        shutil.rmtree(extract_root)
    extract_root.mkdir()

    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_root)

    zip_path.unlink(missing_ok=True)
    extracted = next(extract_root.glob("cheatengine-mcp-bridge-*"), None)
    if not extracted:
        raise RuntimeError("ZIP do bridge veio em formato inesperado")

    if BRIDGE_DIR.exists():
        shutil.rmtree(BRIDGE_DIR)
    extracted.rename(BRIDGE_DIR)
    shutil.rmtree(extract_root, ignore_errors=True)

    if not script.is_file():
        raise RuntimeError(f"bridge incompleto: {script}")
    print(f"[setup] bridge OK: {script}")
    return script


def write_ce_table(lua_path: Path) -> Path:
    lua_esc = str(lua_path).replace("\\", "\\\\")
    xml = f"""<?xml version="1.0" encoding="utf-8"?>
<CheatTable CheatEngineTableVersion="42">
  <CheatEntries/>
  <UserdefinedSymbols/>
  <LuaScript>
--[[ NYX auto-bridge — carrega MCP ao abrir esta table ]]
dofile("{lua_esc}")
  </LuaScript>
</CheatTable>
"""
    CE_TABLE_FILE.write_text(xml, encoding="utf-8")
    return CE_TABLE_FILE


def ce_install_dir() -> Path:
    root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    return root / "NYX" / "CheatEngine"


def find_cheat_engine() -> Path | None:
    local = ce_install_dir() / "cheatengine-x86_64.exe"
    if local.is_file():
        return local

    candidates = [
        Path(r"C:\Program Files\Cheat Engine 7.6\cheatengine-x86_64.exe"),
        Path(r"C:\Program Files\Cheat Engine 7.5\cheatengine-x86_64.exe"),
        Path(r"C:\Program Files\Cheat Engine 7.4\cheatengine-x86_64.exe"),
        Path(r"C:\Program Files\Cheat Engine\cheatengine-x86_64.exe"),
        Path(r"C:\Program Files (x86)\Cheat Engine 7.5\cheatengine-x86_64.exe"),
    ]
    for path in candidates:
        if path.is_file():
            return path

    for base in (Path(r"C:\Program Files"), Path(r"C:\Program Files (x86)")):
        if not base.is_dir():
            continue
        for folder in sorted(base.glob("Cheat Engine*"), reverse=True):
            exe = folder / "cheatengine-x86_64.exe"
            if exe.is_file():
                return exe
    return None


def install_cheat_engine() -> Path | None:
    existing = find_cheat_engine()
    if existing:
        print(f"[setup] Cheat Engine OK: {existing}")
        return existing

    target_dir = ce_install_dir()
    target_dir.mkdir(parents=True, exist_ok=True)
    installer = APP_DIR / "_ce_installer_tmp.exe"

    urls = [CE_INSTALLER_URL, CE_INSTALLER_FALLBACK]
    downloaded = False
    for url in urls:
        try:
            print(f"[setup] baixando Cheat Engine 7.5...")
            req = urllib.request.Request(url, headers={"User-Agent": "NYX-Setup"})
            with urllib.request.urlopen(req, timeout=240) as resp:
                installer.write_bytes(resp.read())
            downloaded = True
            break
        except Exception as exc:
            print(f"[setup] download CE falhou ({url[:48]}...): {exc}")

    if not downloaded or not installer.is_file() or installer.stat().st_size < 1_000_000:
        installer.unlink(missing_ok=True)
        print("[setup] nao foi possivel baixar Cheat Engine — use cheatengine.org se precisar")
        return None

    print("[setup] instalando Cheat Engine (silencioso, sem bundler)...")
    args = [
        str(installer),
        "/VERYSILENT",
        "/SUPPRESSMSGBOXES",
        "/NORESTART",
        "/ZBDIST",
        f"/DIR={target_dir}",
    ]
    try:
        proc = subprocess.run(args, capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        proc = None
        print("[setup] instalacao CE demorou demais — tente de novo ou instale manual")
    finally:
        installer.unlink(missing_ok=True)

    found = find_cheat_engine()
    if found:
        print(f"[setup] Cheat Engine instalado: {found}")
        return found

    code = proc.returncode if proc else -1
    print(f"[setup] CE nao encontrado apos install (exit {code})")
    print("[setup] antivirus pode ter bloqueado — adicione excecao ou instale: https://www.cheatengine.org/")
    return None


def write_abrir_ce_bat(ce_exe: Path | None, table_path: Path) -> None:
    bat = APP_DIR / "ABRIR_CE_BRIDGE.bat"
    if ce_exe:
        lines = [
            "@echo off",
            "cd /d \"%~dp0\"",
            "title BG MODS - Cheat Engine Bridge",
            f"start \"\" \"{ce_exe}\" \"{table_path}\"",
            "echo Cheat Engine aberto com NYX_CE_BRIDGE.ct",
            "echo O bridge MCP carrega automaticamente ao abrir a table.",
            "timeout /t 4 >nul",
        ]
    else:
        lines = [
            "@echo off",
            "cd /d \"%~dp0\"",
            "title BG MODS - Cheat Engine Bridge",
            "echo Cheat Engine nao encontrado.",
            "echo Rode NYX.bat de novo ou instale: https://www.cheatengine.org/",
            "echo Depois abra manualmente a table:",
            f"echo   {table_path}",
            "echo.",
            "pause",
        ]
    bat.write_text("\r\n".join(lines) + "\r\n", encoding="utf-8")


DEFENDER_PS1 = APP_DIR / "nyx_defender.ps1"


def run_av_mode(mode: str) -> None:
    if sys.platform != "win32" or not DEFENDER_PS1.is_file():
        return
    flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
    subprocess.run(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-WindowStyle",
            "Hidden",
            "-File",
            str(DEFENDER_PS1),
            "-Mode",
            mode,
        ],
        check=False,
        creationflags=flags,
    )


def bootstrap_dependencies() -> bool:
    packages = ["customtkinter", "requests", "pillow", "playwright", "mcp", "pywin32", "discord-interactions"]
    print("[setup] instalando dependencias Python...")
    proc = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "pip"],
        capture_output=True,
        text=True,
    )
    proc = subprocess.run(
        [sys.executable, "-m", "pip", "install", *packages],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "").strip()
        print(f"[ERRO] pip install falhou: {err[:400]}")
        return False
    print("[setup] baixando Chromium...")
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)
    return True


def write_launcher() -> Path:
    launcher = NYX_ROOT / "Abrir BG MODS IA.bat"
    NYX_ROOT.mkdir(parents=True, exist_ok=True)
    content = f"""@echo off
cd /d "{APP_DIR}"
title BG MODS IA
"{sys.executable}" nyx_app.py
if errorlevel 1 pause
"""
    launcher.write_text(content, encoding="utf-8")
    return launcher


def mark_installed() -> None:
    (APP_DIR / ".installed").write_text("1", encoding="utf-8")


def _desktop_path() -> Path:
    desktop = Path.home() / "Desktop"
    if not desktop.exists():
        alt = Path.home() / "Área de Trabalho"
        desktop = alt if alt.exists() else desktop
    return desktop


def _logo_ico() -> Path | None:
    for base in (APP_DIR, APP_DIR.parent):
        ico = base / "assets" / "logo.ico"
        if ico.is_file():
            return ico
    return None


def create_desktop_shortcut() -> None:
    launcher = write_launcher()
    desktop = _desktop_path()
    ico = _logo_ico()
    icon_line = f"$lnk.IconLocation = '{ico}'" if ico else "$lnk.IconLocation = 'shell32.dll,13'"
    ps = f"""
$WshShell = New-Object -ComObject WScript.Shell
$lnk = $WshShell.CreateShortcut('{desktop / "BG MODS IA.lnk"}')
$lnk.TargetPath = '{launcher}'
$lnk.WorkingDirectory = '{APP_DIR}'
$lnk.Description = 'BG MODS IA'
{icon_line}
$lnk.Save()
"""
    subprocess.run(
        ["powershell", "-NoProfile", "-Command", ps],
        check=False,
        capture_output=True,
        text=True,
    )


def get_ollama_exe() -> str | None:
    found = shutil.which("ollama")
    if found:
        return found
    local = Path(__import__("os").environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe"
    if local.is_file():
        return str(local)
    return None


def wait_ollama(url: str, timeout: float = 120) -> bool:
    import time

    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(url, timeout=3)
            return True
        except Exception:
            time.sleep(2)
    return False


def try_ollama_pull(model: str) -> bool:
    ollama = get_ollama_exe()
    if not ollama:
        return False

    base = load_config().get("ollama_url", "http://localhost:11434").rstrip("/")
    if not wait_ollama(f"{base}/", timeout=90):
        print("[setup] ollama offline — pulando download de modelo")
        return False

    print(f"[setup] baixando modelo {model} ...")
    proc = subprocess.run([ollama, "pull", model], capture_output=True, text=True)
    if proc.returncode == 0:
        print("[setup] modelo ollama OK")
        return True
    err = (proc.stderr or proc.stdout or "").strip()
    print(f"[setup] ollama pull falhou (nao critico): {err[:200]}")
    return False


def verify_imports() -> list[str]:
    missing = []
    for mod in ("customtkinter", "requests", "PIL", "playwright", "mcp", "win32file", "discord_interactions"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    return missing


def main() -> int:
    bootstrap = "--bootstrap" in sys.argv

    print("=" * 50)
    print(" NYX — configuracao automatica")
    print("=" * 50)
    print(f" pasta: {APP_DIR}\n")

    if bootstrap:
        run_av_mode("prepare")

    try:
        if bootstrap:
            if not bootstrap_dependencies():
                return 1

        missing = verify_imports()
        if missing:
            print("[ERRO] modulos faltando:", ", ".join(missing))
            if bootstrap:
                print("bootstrap falhou ao instalar dependencias.")
            else:
                print("rode com --bootstrap ou INSTALAR_TUDO.bat antes.")
            return 1

        bridge_script = download_bridge()
        lua_path = BRIDGE_DIR / "MCP_Server" / "ce_mcp_bridge.lua"
        table_path = write_ce_table(lua_path)
        ce_exe = install_cheat_engine()
        write_abrir_ce_bat(ce_exe, table_path)

        config = load_config()
        config["agent_mode"] = True
        config["ce_mcp_enabled"] = True
        config["ce_mcp_script"] = str(bridge_script.resolve())
        if not config.get("assistant_name"):
            config["assistant_name"] = "BG MODS IA"
        save_config(config)
        ensure_user_data_dirs()
        write_launcher()
        create_desktop_shortcut()
        mark_installed()

        try_ollama_pull(config["ollama_model"])
        try_ollama_pull(config["ollama_vision_model"])

        print("\n[OK] config.json gravado:")
        print(f"     ce_mcp_enabled = true")
        print(f"     ce_mcp_script  = {config['ce_mcp_script']}")
        print(f"     agent_mode     = true")
        print(f"\n[OK] NYX_CE_BRIDGE.ct — abre CE com bridge auto")
        print(f"[OK] atalho Desktop: BG MODS IA.lnk (se possivel)")
        if ce_exe:
            print(f"[OK] Cheat Engine: {ce_exe}")
        else:
            print("[!!] Cheat Engine — rode NYX.bat de novo se faltou")
        print("\nProximo passo: duplo clique ABRIR_NYX.bat")
        return 0
    finally:
        if bootstrap:
            run_av_mode("restore")


if __name__ == "__main__":
    raise SystemExit(main())
