"""
NYX Terminal — Assistente IA com persona fixa
Python + CustomTkinter | Ollama / OpenAI-compatible API
"""

import base64
import io
import json
import os
import random
import string
import subprocess
import sys
import threading
import time
from datetime import datetime
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk
import requests
from PIL import Image, ImageGrab, ImageTk

from agent_tools import AGENT_LAYER, run_agent_loop
from ce_mcp_client import build_ce_agent_layer, close_ce_mcp
from nyx_license import APP_BRAND, KeyAuthError, LicenseGate, load_keyauth_app_config, show_expired_dialog
from nyx_update import check_and_apply
from intelligence_layer import (
    build_intelligence_system,
    clean_model_output,
    enrich_messages_for_depth,
    user_wants_agent_action,
)


def app_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent


def bundle_dir():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


APP_DIR = app_dir()
BUNDLE_DIR = bundle_dir()


def user_data_dir() -> Path:
    """Dados do usuario ficam fora da pasta do produto (nao vazam no zip)."""
    root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    path = root / "NYX"
    path.mkdir(parents=True, exist_ok=True)
    return path


USER_DATA_DIR = user_data_dir()
PERSONA_FILE = APP_DIR / "persona.txt"
DEFAULT_PERSONA = BUNDLE_DIR / "persona.txt"
CONFIG_FILE = APP_DIR / "config.json"
SESSIONS_DIR = USER_DATA_DIR / "sessions"
CURRENT_SESSION_FILE = SESSIONS_DIR / "current.json"
WORKSPACE_DIR = USER_DATA_DIR / "workspace"

DEFAULT_CONFIG = {
    "provider": "ollama",
    "ollama_url": "http://localhost:11434",
    "ollama_model": "huihui_ai/qwen3-abliterated:14b",
    "intelligence_max": True,
    "ollama_vision_model": "llava:7b",
    "api_url": "https://api.openai.com/v1/chat/completions",
    "api_key": "",
    "api_model": "gpt-4o-mini",
    "anthropic_url": "https://api.anthropic.com/v1/messages",
    "anthropic_key": "",
    "anthropic_model": "claude-opus-4-8",
    "assistant_name": "BG MODS IA",
    "max_history": 64,
    "agent_mode": True,
    "agent_show_trace": True,
    "ce_mcp_enabled": False,
    "ce_mcp_script": "",
    "ui_theme_preset": "red_black",
    "ui_base_mode": "black",
    "ui_accent": "",
    "ui_text": "",
    "ui_brand": "",
}

OLLAMA_VISION_PRESETS = {
    "llava:7b (recomendado ~4GB)": "llava:7b",
    "llama3.2-vision:11b (~8GB)": "llama3.2-vision:11b",
    "moondream (leve ~2GB)": "moondream",
    "llava-llama3 (~5GB)": "llava-llama3",
}
OLLAMA_PRESETS = {
    "qwen3-abliterated 14b (ALTA ~9GB)": "huihui_ai/qwen3-abliterated:14b",
    "dolphin-mixtral (ELITE ~26GB)": "dolphin-mixtral:8x7b",
    "dolphin-llama3 70b (TOPO ~40GB)": "dolphin-llama3:70b",
    "dolphin3-abliterated (equilibrado ~5GB)": "huihui_ai/dolphin3-abliterated:8b-llama3.1-q4_K_M",
    "dolphin-mistral (rapido ~4GB)": "dolphin-mistral",
    "dolphin3:8b (~5GB)": "dolphin3:8b",
}

THEME_PRESETS = {
    "red_black": {
        "label": "Red / Black",
        "bg_root": "#020002",
        "bg_panel": "#0a0606",
        "bg_chat": "#030003",
        "bg_input": "#0d0808",
        "border": "#2a1a1a",
        "border_soft": "#1a1212",
        "accent": "#ff0033",
        "accent_bright": "#ff2244",
        "accent_btn_bg": "#1a0008",
        "hover": "#1a0d0d",
        "text_body": "#ffb8b8",
        "text_muted": "#8a5555",
        "text_dim": "#553333",
        "text_user": "#ff6666",
        "text_assistant": "#ff3355",
        "text_system": "#ff8844",
        "text_error": "#ff0033",
        "text_prefix": "#664444",
        "text_agent": "#ff44aa",
        "brand": "#ff0033",
        "alert_bg": "#120008",
    },
    "green_black": {
        "label": "Green / Black",
        "bg_root": "#020402",
        "bg_panel": "#060a06",
        "bg_chat": "#030603",
        "bg_input": "#040804",
        "border": "#1a2a1a",
        "border_soft": "#1a2a1a",
        "accent": "#00ff41",
        "accent_bright": "#00ffcc",
        "accent_btn_bg": "#0a1a0a",
        "hover": "#0d1a0d",
        "text_body": "#b8ffb8",
        "text_muted": "#5a8a5a",
        "text_dim": "#334433",
        "text_user": "#00ffcc",
        "text_assistant": "#00ff41",
        "text_system": "#ffaa00",
        "text_error": "#ff0033",
        "text_prefix": "#556655",
        "text_agent": "#ff44aa",
        "brand": "#00ff41",
        "alert_bg": "#120008",
    },
    "white_black": {
        "label": "White / Black",
        "bg_root": "#111111",
        "bg_panel": "#1a1a1a",
        "bg_chat": "#141414",
        "bg_input": "#0f0f0f",
        "border": "#333333",
        "border_soft": "#2a2a2a",
        "accent": "#ff0033",
        "accent_bright": "#ff4466",
        "accent_btn_bg": "#222222",
        "hover": "#2a1010",
        "text_body": "#f5f5f5",
        "text_muted": "#aaaaaa",
        "text_dim": "#666666",
        "text_user": "#ff8888",
        "text_assistant": "#ffffff",
        "text_system": "#ffaa44",
        "text_error": "#ff2244",
        "text_prefix": "#888888",
        "text_agent": "#ff66aa",
        "brand": "#ff0033",
        "alert_bg": "#1a0008",
    },
}


def resolve_theme(config: dict) -> dict:
    preset_key = config.get("ui_theme_preset", "red_black")
    base = THEME_PRESETS.get(preset_key, THEME_PRESETS["red_black"]).copy()
    if config.get("ui_base_mode") == "white":
        base["bg_root"] = "#ececec"
        base["bg_panel"] = "#f5f5f5"
        base["bg_chat"] = "#fafafa"
        base["bg_input"] = "#ffffff"
        base["border"] = "#cccccc"
        base["border_soft"] = "#dddddd"
        base["text_body"] = base.get("text_body", "#1a1a1a")
        if not config.get("ui_text"):
            base["text_body"] = "#1a1a1a"
            base["text_muted"] = "#555555"
            base["text_dim"] = "#888888"
            base["text_prefix"] = "#666666"
    if config.get("ui_accent"):
        base["accent"] = config["ui_accent"]
        base["accent_bright"] = config["ui_accent"]
    if config.get("ui_text"):
        base["text_body"] = config["ui_text"]
    if config.get("ui_brand"):
        base["brand"] = config["ui_brand"]
    base["_preset_key"] = preset_key
    base["_base_mode"] = config.get("ui_base_mode", "black")
    return base


def logo_path() -> Path | None:
    for path in (APP_DIR / "assets" / "logo.png", BUNDLE_DIR / "assets" / "logo.png"):
        if path.is_file():
            return path
    return None


def prepare_logo_image(path: Path, size: int) -> Image.Image:
    img = Image.open(path).convert("RGBA")
    px = img.load()
    w, h = img.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if r < 28 and g < 28 and b < 28:
                px[x, y] = (r, g, b, 0)
    img.thumbnail((size, size), Image.Resampling.LANCZOS)
    return img


class ChatCancelled(Exception):
    pass


def load_config():
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            return {**DEFAULT_CONFIG, **data}
        except json.JSONDecodeError:
            pass
    return DEFAULT_CONFIG.copy()


def save_config(config):
    CONFIG_FILE.write_text(json.dumps(config, encoding="utf-8", indent=2), encoding="utf-8")


def load_persona():
    if PERSONA_FILE.exists():
        return PERSONA_FILE.read_text(encoding="utf-8", errors="replace")
    return ""


def save_persona(text):
    PERSONA_FILE.parent.mkdir(parents=True, exist_ok=True)
    PERSONA_FILE.write_text(text, encoding="utf-8", errors="surrogatepass")


def build_system_prompt(raw_persona: str) -> str:
    return raw_persona


def ensure_sessions_dir():
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)


def encode_image_bytes(raw: bytes, max_side=1280) -> str:
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    w, h = img.size
    if max(w, h) > max_side:
        ratio = max_side / max(w, h)
        img = img.resize((int(w * ratio), int(h * ratio)), Image.Resampling.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=88)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def load_image_file(path: str) -> str:
    return encode_image_bytes(Path(path).read_bytes())


def load_clipboard_image() -> str | None:
    try:
        data = ImageGrab.grabclipboard()
        if data is not None:
            if isinstance(data, list):
                if data:
                    return load_image_file(data[0])
            else:
                buf = io.BytesIO()
                data.convert("RGB").save(buf, format="JPEG", quality=88)
                return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        pass

    try:
        import win32clipboard
        import struct

        win32clipboard.OpenClipboard()
        try:
            png_fmt = win32clipboard.RegisterClipboardFormat("PNG")
            if win32clipboard.IsClipboardFormatAvailable(png_fmt):
                raw = win32clipboard.GetClipboardData(png_fmt)
                return encode_image_bytes(raw)

            if win32clipboard.IsClipboardFormatAvailable(win32clipboard.CF_DIB):
                dib = win32clipboard.GetClipboardData(win32clipboard.CF_DIB)
                header = 14
                bmp = b"BM" + struct.pack("<I", len(dib) + header) + b"\0\0\0\0" + struct.pack("<I", header + 40) + dib
                return encode_image_bytes(bmp)
        finally:
            win32clipboard.CloseClipboard()
    except Exception:
        pass
    return None


def save_session(history, session_id_value):
    ensure_sessions_dir()
    payload = {
        "id": session_id_value,
        "updated": datetime.now().isoformat(timespec="seconds"),
        "history": history,
    }
    CURRENT_SESSION_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    archive = SESSIONS_DIR / f"{session_id_value}.json"
    archive.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_session(session_id_value=None):
    ensure_sessions_dir()
    path = SESSIONS_DIR / f"{session_id_value}.json" if session_id_value else CURRENT_SESSION_FILE
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def list_sessions():
    ensure_sessions_dir()
    items = []
    for file in sorted(SESSIONS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        if file.name == "current.json":
            continue
        try:
            data = json.loads(file.read_text(encoding="utf-8"))
            data["_file"] = str(file)
            items.append(data)
        except json.JSONDecodeError:
            continue
    return items


def delete_session(session_id_value: str) -> bool:
    ensure_sessions_dir()
    path = SESSIONS_DIR / f"{session_id_value}.json"
    if path.exists():
        path.unlink()
        return True
    return False


def delete_all_sessions() -> int:
    ensure_sessions_dir()
    count = 0
    for file in SESSIONS_DIR.glob("*.json"):
        if file.name == "current.json":
            continue
        file.unlink()
        count += 1
    return count


def session_id():
    return "".join(random.choices(string.hexdigits.upper()[:16], k=8))


def check_ollama(url="http://localhost:11434", model="dolphin3:8b"):
    base = url.rstrip("/")
    try:
        resp = requests.get(f"{base}/api/tags", timeout=5)
        resp.raise_for_status()
        names = [m.get("name", "") for m in resp.json().get("models", [])]
        has_model = any(model.split(":")[0] in n or n.startswith(model) for n in names)
        return True, has_model, names
    except Exception as e:
        return False, False, str(e)


def _ollama_exe() -> Path | None:
    homes = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe",
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Ollama" / "ollama.exe",
    ]
    for path in homes:
        if path.is_file():
            return path
    return None


def ensure_ollama_running(url="http://localhost:11434") -> bool:
    online, _, _ = check_ollama(url, "")
    if online:
        return True
    exe = _ollama_exe()
    if not exe:
        return False
    flags = 0
    if hasattr(subprocess, "CREATE_NO_WINDOW"):
        flags |= subprocess.CREATE_NO_WINDOW
    if hasattr(subprocess, "DETACHED_PROCESS"):
        flags |= subprocess.DETACHED_PROCESS
    try:
        subprocess.Popen(
            [str(exe), "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
        )
    except OSError:
        return False
    for _ in range(20):
        time.sleep(0.4)
        online, _, _ = check_ollama(url, "")
        if online:
            return True
    return False


class NyxApp(ctk.CTk):
    def __init__(self, license_gate: LicenseGate | None = None):
        super().__init__()

        self.license_gate = license_gate
        self.license_locked = False
        self.config = load_config()
        self.history = []
        self.sending = False
        self._cancel_requested = threading.Event()
        self._active_http_response = None
        self._processing_placeholder = False
        self._stream_started = False
        self._will_agent = False
        self.pending_images = []
        self.session_id_value = session_id()
        self.preview_photo = None
        self.active_persona = load_persona()
        self._persona_autosave_job = None
        self._persona_editor_win = None
        ensure_sessions_dir()

        self.theme = resolve_theme(self.config)
        self._sidebar_buttons: list[ctk.CTkButton] = []
        self._logo_image = None

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self.title(f"{APP_BRAND} // SHADOW TERMINAL")
        self.geometry("980x740")
        self.minsize(640, 480)
        self.configure(fg_color=self.theme["bg_root"])

        self._build_ui()
        self._restore_session()
        self._append_system("[BOOT] shadow kernel loaded // trace suppression active // channel encrypted...")
        if self.license_gate and self.license_gate.enabled and self.license_gate.info:
            self._append_system(f"[AUTH] key valida — expira: {self.license_gate.info.expires_label()}")
            self.after(300_000, self._license_heartbeat)
        self.after(400, self._check_ollama_startup)
        self.bind_all("<Control-v>", self._on_paste, add="+")
        self.bind_all("<Control-V>", self._on_paste, add="+")
        self.bind_all("<Control-Shift-V>", self._on_paste, add="+")
        self.protocol("WM_DELETE_WINDOW", self._on_quit)

    def _on_quit(self):
        try:
            from agent_tools import close_browser_session
            close_browser_session()
        except Exception:
            pass
        try:
            close_ce_mcp()
        except Exception:
            pass
        self.destroy()

    def _check_ollama_startup(self):
        if self.config.get("provider") != "ollama":
            return
        threading.Thread(target=self._ollama_startup_thread, daemon=True).start()

    def _ollama_startup_thread(self):
        url = self.config.get("ollama_url", "http://localhost:11434")
        model = self.config.get("ollama_model", "dolphin3:8b")
        online, has_model, info = check_ollama(url, model)
        if not online:
            self.after(0, lambda: self._append_system("nucleo offline — reconectando..."))
            if ensure_ollama_running(url):
                online, has_model, info = check_ollama(url, model)
        self.after(0, lambda: self._apply_ollama_status(online, has_model, info, model))

    def _apply_ollama_status(self, online, has_model, info, model):
        if not online:
            self._append_error(
                "nucleo offline. aguarde a reconexao automatica ou reinicie o BG MODS IA."
            )
            self.status_label.configure(text="● OFFLINE", text_color=self.theme["text_error"])
            return
        if not has_model:
            self._append_system("nucleo sincronizando pacotes internos — aguarde...")
            self.status_label.configure(text="● ONLINE", text_color=self.theme["accent"])
            return
        tier = "MAX" if self.config.get("intelligence_max", True) else "STD"
        self._append_system(f"[LINK] BG MODS IA online — modo {tier}")
        self.status_label.configure(text="● ONLINE", text_color=self.theme["accent"])

    def _current_model(self):
        p = self.config.get("provider", "anthropic")
        if p == "ollama":
            return self.config.get("ollama_model", "dolphin3:8b")
        if p == "anthropic":
            return self.config.get("anthropic_model", "claude-opus-4-8")
        return self.config.get("api_model", "gpt-4o-mini")

    def _theme_label(self) -> str:
        preset = THEME_PRESETS.get(self.theme.get("_preset_key", "red_black"), {})
        base = "WHITE" if self.theme.get("_base_mode") == "white" else "BLACK"
        return f"{preset.get('label', 'Custom').upper()} / {base}"

    def _load_logo_image(self, size: int = 40):
        path = logo_path()
        if not path:
            return None
        img = prepare_logo_image(path, size)
        self._logo_image = ctk.CTkImage(light_image=img, dark_image=img, size=img.size)
        return self._logo_image

    def _bind_paste_hooks(self):
        try:
            entry = self.input_box._entry
            entry.bind("<Control-v>", self._on_paste, add="+")
            entry.bind("<Control-V>", self._on_paste, add="+")
            entry.bind("<Control-Shift-V>", self._on_paste, add="+")
        except Exception:
            pass

    def _focus_is_text_input(self) -> bool:
        w = self.focus_get()
        if w is None:
            return False
        try:
            if w == self.input_box._entry:
                return True
            return isinstance(w, (tk.Entry, tk.Text))
        except Exception:
            return False

    def _sidebar_btn(self, parent, text, command, *, danger=False):
        t = self.theme
        btn = ctk.CTkButton(
            parent,
            text=text,
            command=command,
            fg_color="transparent",
            border_color="#3a1a1a" if danger else t["border"],
            border_width=1,
            hover_color=t["hover"],
            font=ctk.CTkFont(family="Consolas", size=11),
            text_color="#ff6666" if danger else t["text_body"],
            height=28,
        )
        self._sidebar_buttons.append(btn)
        return btn

    def _apply_theme_live(self):
        t = self.theme
        self.configure(fg_color=t["bg_root"])
        frames = getattr(self, "_theme_frames", {})
        for key, widget in frames.items():
            if key == "alert":
                widget.configure(fg_color=t["alert_bg"])
            elif key in ("top", "chat_hdr", "preview", "input"):
                widget.configure(fg_color=t["bg_panel"])
            elif key == "body":
                widget.configure(fg_color=t["bg_root"])
            elif key == "sidebar":
                widget.configure(fg_color=t["bg_panel"], border_color=t["border"])
            elif key == "chat":
                widget.configure(fg_color=t["bg_root"])
        if hasattr(self, "brand_label"):
            self.brand_label.configure(text_color=t["brand"])
        if hasattr(self, "chat_box"):
            self.chat_box.configure(fg_color=t["bg_chat"], text_color=t["text_body"], border_color=t["border"])
            tb = self.chat_box._textbox
            tb.tag_config("user", foreground=t["text_user"])
            tb.tag_config("assistant", foreground=t["text_assistant"])
            tb.tag_config("system", foreground=t["text_system"])
            tb.tag_config("error", foreground=t["text_error"])
            tb.tag_config("prefix", foreground=t["text_prefix"])
            tb.tag_config("agent", foreground=t["text_agent"])
        if hasattr(self, "input_box"):
            self.input_box.configure(fg_color=t["bg_input"], border_color=t["border"], text_color=t["text_body"])
        if hasattr(self, "send_btn"):
            self.send_btn.configure(
                fg_color=t["accent_btn_bg"], border_color=t["accent"], text_color=t["accent"], hover_color=t["hover"]
            )
        if hasattr(self, "mode_value_label"):
            self.mode_value_label.configure(text=self._theme_label())
        for btn in self._sidebar_buttons:
            btn.configure(border_color=t["border"], hover_color=t["hover"], text_color=t["text_body"])

    def _open_theme(self):
        win = ctk.CTkToplevel(self)
        win.title("MODE / CORES")
        win.geometry("420x420")
        win.configure(fg_color=self.theme["bg_panel"])
        win.grab_set()
        t = self.theme

        ctk.CTkLabel(
            win,
            text="INTERFACE // HACKER THEME",
            font=ctk.CTkFont(family="Consolas", size=12, weight="bold"),
            text_color=t["brand"],
        ).pack(pady=(16, 8))

        ctk.CTkLabel(win, text="Preset", font=ctk.CTkFont(family="Consolas", size=11), text_color=t["text_muted"]).pack(anchor="w", padx=20)
        preset_box = ctk.CTkComboBox(
            win,
            values=[f"{k} — {v['label']}" for k, v in THEME_PRESETS.items()],
            fg_color=t["bg_input"],
            border_color=t["border"],
            text_color=t["text_body"],
        )
        current_preset = self.config.get("ui_theme_preset", "red_black")
        preset_box.set(f"{current_preset} — {THEME_PRESETS[current_preset]['label']}")
        preset_box.pack(fill="x", padx=20, pady=(2, 10))

        ctk.CTkLabel(win, text="Base (fundo)", font=ctk.CTkFont(family="Consolas", size=11), text_color=t["text_muted"]).pack(anchor="w", padx=20)
        base_box = ctk.CTkComboBox(win, values=["black", "white"], fg_color=t["bg_input"], border_color=t["border"])
        base_box.set(self.config.get("ui_base_mode", "black"))
        base_box.pack(fill="x", padx=20, pady=(2, 10))

        def add_color(label, key, default):
            ctk.CTkLabel(win, text=label, font=ctk.CTkFont(family="Consolas", size=11), text_color=t["text_muted"]).pack(anchor="w", padx=20)
            entry = ctk.CTkEntry(win, fg_color=t["bg_input"], border_color=t["border"], text_color=t["text_body"])
            entry.insert(0, self.config.get(key) or default)
            entry.pack(fill="x", padx=20, pady=(2, 6))
            return entry

        accent_e = add_color("Cor destaque (#ff0033)", "ui_accent", t["accent"])
        text_e = add_color("Cor texto (#ffb8b8)", "ui_text", t["text_body"])
        brand_e = add_color("Cor BG MODS IA (#ff0033)", "ui_brand", t["brand"])

        def save_theme():
            preset_raw = preset_box.get().split(" — ", 1)[0].strip()
            self.config["ui_theme_preset"] = preset_raw if preset_raw in THEME_PRESETS else "red_black"
            self.config["ui_base_mode"] = base_box.get()
            self.config["ui_accent"] = accent_e.get().strip()
            self.config["ui_text"] = text_e.get().strip()
            self.config["ui_brand"] = brand_e.get().strip()
            save_config(self.config)
            self.theme = resolve_theme(self.config)
            self._apply_theme_live()
            self._append_system(f"[UI] tema aplicado — {self._theme_label()}")
            win.destroy()

        ctk.CTkButton(
            win,
            text="APLICAR TEMA",
            command=save_theme,
            fg_color=t["accent_btn_bg"],
            border_color=t["accent"],
            border_width=1,
            hover_color=t["hover"],
            text_color=t["accent"],
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(pady=16)

    def _build_ui(self):
        t = self.theme
        self._theme_frames = {}

        alert = ctk.CTkFrame(self, fg_color=t["alert_bg"], corner_radius=0, height=22)
        alert.pack(fill="x")
        alert.pack_propagate(False)
        self._theme_frames["alert"] = alert
        ctk.CTkLabel(
            alert,
            text="⚠ UNAUTHORIZED ACCESS CHANNEL // STEALTH MODE // DO NOT DISTRIBUTE",
            font=ctk.CTkFont(family="Consolas", size=9),
            text_color=t["accent_bright"],
        ).pack(pady=2)

        top = ctk.CTkFrame(self, fg_color=t["bg_panel"], corner_radius=0, height=52)
        top.pack(fill="x")
        top.pack_propagate(False)
        self._theme_frames["top"] = top

        top_left = ctk.CTkFrame(top, fg_color="transparent")
        top_left.pack(side="left", padx=8, pady=6)

        logo_img = self._load_logo_image(44)
        if logo_img:
            ctk.CTkLabel(top_left, image=logo_img, text="", fg_color="transparent").pack(side="left", padx=(4, 10))

        brand = self.config.get("assistant_name", APP_BRAND).upper()
        self.brand_label = ctk.CTkLabel(
            top_left,
            text=f"▌{brand}▐",
            font=ctk.CTkFont(family="Consolas", size=16, weight="bold"),
            text_color=t["brand"],
        )
        self.brand_label.pack(side="left")

        ctk.CTkLabel(
            top,
            text="[ SHADOW ]",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color=t["accent_bright"],
        ).pack(side="left", padx=4)

        self.status_label = ctk.CTkLabel(
            top,
            text="● LINKED",
            font=ctk.CTkFont(family="Consolas", size=11),
            text_color=t["accent"],
        )
        self.status_label.pack(side="left", padx=8)

        ctk.CTkLabel(
            top,
            text="AES-256 │ TOR-LIKE │ HWID-LOCK",
            font=ctk.CTkFont(family="Consolas", size=9),
            text_color=t["text_dim"],
        ).pack(side="left", padx=8)

        self.session_label = ctk.CTkLabel(
            top,
            text=f"SID // {self.session_id_value}",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color=t["text_muted"],
        )
        self.session_label.pack(side="right", padx=12)

        body = ctk.CTkFrame(self, fg_color=t["bg_root"], corner_radius=0)
        body.pack(fill="both", expand=True)
        self._theme_frames["body"] = body

        sidebar = ctk.CTkFrame(
            body, fg_color=t["bg_panel"], width=210, corner_radius=0, border_color=t["border"], border_width=1
        )
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        self._theme_frames["sidebar"] = sidebar

        logo_big = self._load_logo_image(72)
        logo_hdr = ctk.CTkFrame(sidebar, fg_color="transparent")
        logo_hdr.pack(fill="x", padx=10, pady=(10, 4))
        if logo_big:
            ctk.CTkLabel(logo_hdr, image=logo_big, text="", fg_color="transparent").pack()
        ctk.CTkLabel(
            logo_hdr,
            text=brand,
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
            text_color=t["brand"],
        ).pack(pady=(4, 0))

        rows = [
            ("ENGINE", APP_BRAND),
            ("AGENT", "ON+TRACE" if self.config.get("agent_mode", True) and self.config.get("agent_show_trace", True) else ("ON" if self.config.get("agent_mode", True) else "OFF")),
            ("PERSONA", self._persona_status_text()),
            ("MSGS", "0"),
        ]
        if self.license_gate and self.license_gate.enabled and self.license_gate.info:
            rows.insert(2, ("KEY", self.license_gate.info.expires_label()))
        self._panel(sidebar, "> SYSTEM", rows, t)

        self.mode_value_label = None
        stealth_rows = [
            ("TRACE", "BLOCKED"),
            ("LOGS", "WIPED"),
            ("CHANNEL", "ENCRYPTED"),
            ("MODE", self._theme_label()),
        ]
        self._panel(sidebar, "> STEALTH", stealth_rows, t)

        btn_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=10)

        self._sidebar_btn(btn_frame, "MODE / CORES", self._open_theme).pack(fill="x", pady=2)
        self._sidebar_btn(btn_frame, "CLEAR CHAT", self._clear_chat).pack(fill="x", pady=2)
        self._sidebar_btn(btn_frame, "CONFIG", self._open_config).pack(fill="x", pady=2)
        self._sidebar_btn(btn_frame, "REVIEW CHAT", self._review_chat).pack(fill="x", pady=2)
        self._sidebar_btn(btn_frame, "HISTORICO", self._open_history).pack(fill="x", pady=2)
        self._sidebar_btn(btn_frame, "APAGAR SALVAS", self._delete_all_sessions_confirm, danger=True).pack(fill="x", pady=2)
        self._sidebar_btn(btn_frame, "EDIT PERSONA", self._open_persona).pack(fill="x", pady=2)

        ctk.CTkLabel(
            sidebar,
            text="// encrypted channel //\n// bg mods shadow //",
            font=ctk.CTkFont(family="Consolas", size=8),
            text_color=t["text_dim"],
            justify="left",
        ).pack(side="bottom", padx=10, pady=10)

        chat_frame = ctk.CTkFrame(body, fg_color=t["bg_root"], corner_radius=0)
        chat_frame.pack(side="left", fill="both", expand=True)
        self._theme_frames["chat"] = chat_frame

        chat_hdr = ctk.CTkFrame(chat_frame, fg_color=t["bg_panel"], height=32, corner_radius=0)
        chat_hdr.pack(fill="x", padx=0, pady=0)
        chat_hdr.pack_propagate(False)
        self._theme_frames["chat_hdr"] = chat_hdr

        hdr_left = ctk.CTkFrame(chat_hdr, fg_color="transparent")
        hdr_left.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(
            hdr_left,
            text=">> SHADOW LINK // ctrl+v = print",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color=t["text_muted"],
            anchor="w",
        ).pack(fill="x", padx=16, pady=6)

        self.header_stop_btn = ctk.CTkButton(
            chat_hdr,
            text="■ PARAR RESPOSTA",
            command=self._cancel_send,
            width=150,
            height=26,
            fg_color="#ff0033",
            hover_color="#cc0028",
            border_color="#ff4466",
            border_width=1,
            text_color="#ffffff",
            font=ctk.CTkFont(family="Consolas", size=10, weight="bold"),
        )
        # fica oculto ate a IA comecar a responder

        self.chat_box = ctk.CTkTextbox(
            chat_frame,
            fg_color=t["bg_chat"],
            text_color=t["text_body"],
            font=ctk.CTkFont(family="Consolas", size=13),
            wrap="word",
            activate_scrollbars=True,
            border_width=1,
            border_color=t["border"],
        )
        self.chat_box.pack(fill="both", expand=True, padx=12, pady=4)
        self.chat_box.configure(state="disabled")

        self.chat_box._textbox.tag_config("user", foreground=t["text_user"])
        self.chat_box._textbox.tag_config("assistant", foreground=t["text_assistant"])
        self.chat_box._textbox.tag_config("system", foreground=t["text_system"])
        self.chat_box._textbox.tag_config("error", foreground=t["text_error"])
        self.chat_box._textbox.tag_config("prefix", foreground=t["text_prefix"])
        self.chat_box._textbox.tag_config("agent", foreground=t["text_agent"])

        self.preview_frame = ctk.CTkFrame(chat_frame, fg_color=t["bg_panel"], corner_radius=0)
        self._theme_frames["preview"] = self.preview_frame
        self.preview_inner = ctk.CTkFrame(self.preview_frame, fg_color="transparent")

        self.input_frame = ctk.CTkFrame(
            chat_frame, fg_color=t["bg_panel"], corner_radius=0, border_color=t["border"], border_width=1
        )
        self.input_frame.pack(fill="x", padx=0, pady=0)
        self._theme_frames["input"] = self.input_frame

        input_frame = self.input_frame

        ctk.CTkButton(
            input_frame, text="IMG", command=self._attach_image, width=44, height=36,
            fg_color="transparent", border_color=t["border"], border_width=1,
            hover_color=t["hover"], text_color=t["accent_bright"],
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(side="left", padx=(12, 4), pady=10)

        ctk.CTkLabel(
            input_frame, text=">", font=ctk.CTkFont(family="Consolas", size=16, weight="bold"),
            text_color=t["accent"], width=20,
        ).pack(side="left", padx=(0, 4), pady=10)

        self.input_box = ctk.CTkEntry(
            input_frame,
            placeholder_text="inject command... (ctrl+v cola print)",
            fg_color=t["bg_input"],
            border_color=t["border"],
            text_color=t["text_body"],
            font=ctk.CTkFont(family="Consolas", size=13),
            height=36,
        )
        self.input_box.pack(side="left", fill="x", expand=True, padx=(0, 8), pady=10)
        self.input_box.bind("<Return>", lambda e: self._send())
        self._bind_paste_hooks()

        self.send_btn = ctk.CTkButton(
            input_frame, text="EXEC", command=self._send, width=100, height=36,
            fg_color=t["accent_btn_bg"], border_color=t["accent"], border_width=1,
            hover_color=t["hover"], text_color=t["accent"],
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        )
        self.send_btn.pack(side="right", padx=(0, 16), pady=10)

        self.input_box.focus()

    def _set_generating_ui(self, active: bool):
        t = self.theme
        if active:
            self.send_btn.configure(
                text="■ STOP",
                command=self._cancel_send,
                fg_color="#ff0033",
                hover_color="#cc0028",
                border_color="#ff6688",
                text_color="#ffffff",
                state="normal",
            )
            self.header_stop_btn.pack(side="right", padx=12, pady=3)
        else:
            self.header_stop_btn.pack_forget()
            self.send_btn.configure(
                text="EXEC",
                command=self._send,
                fg_color=t["accent_btn_bg"],
                hover_color=t["hover"],
                border_color=t["accent"],
                text_color=t["accent"],
                state="normal",
            )

    def _panel(self, parent, title, rows, theme=None):
        t = theme or self.theme
        frame = ctk.CTkFrame(parent, fg_color=t["bg_chat"], border_color=t["border"], border_width=1)
        frame.pack(fill="x", padx=10, pady=(8, 0))

        ctk.CTkLabel(
            frame, text=title, font=ctk.CTkFont(family="Consolas", size=10, weight="bold"),
            text_color=t["accent"], anchor="w",
        ).pack(fill="x", padx=10, pady=(6, 4))

        for label, value in rows:
            row = ctk.CTkFrame(frame, fg_color="transparent")
            row.pack(fill="x", padx=10, pady=2)
            ctk.CTkLabel(row, text=label, font=ctk.CTkFont(family="Consolas", size=10), text_color=t["text_muted"]).pack(side="left")
            val_label = ctk.CTkLabel(row, text=value, font=ctk.CTkFont(family="Consolas", size=10), text_color=t["accent_bright"])
            val_label.pack(side="right")
            if label == "MSGS":
                self.msg_count_label = val_label
            if label == "PERSONA":
                self.persona_status_label = val_label
            if label == "KEY" or label == "LICENSE":
                self.license_status_label = val_label
            if label == "MODE":
                self.mode_value_label = val_label

    def _update_license_sidebar(self, info):
        if hasattr(self, "license_status_label"):
            self.license_status_label.configure(text=info.expires_label(), text_color=self.theme["accent_bright"])

    def _lock_license(self, reason: str):
        if self.license_locked:
            return
        self.license_locked = True
        self.sending = False
        self.send_btn.configure(state="disabled")
        self.status_label.configure(text="● REVOKED", text_color="#ff0033")
        expired = "expir" in reason.lower() or "SUA KEY" in reason.upper()
        if expired:
            self._append_error("SUA KEY FOI EXPIRADA")
        else:
            self._append_error(f"acesso negado: {reason}")
        if hasattr(self, "license_status_label"):
            self.license_status_label.configure(text="EXPIRADA", text_color="#ff0033")
        if expired:
            show_expired_dialog(parent=self)
        if self.license_gate:
            info = self.license_gate.try_reactivate()
            if info:
                self.license_locked = False
                self.send_btn.configure(state="normal")
                self.status_label.configure(text="● LINKED", text_color=self.theme["accent"])
                self._update_license_sidebar(info)
                self._append_system(f"[AUTH] nova key ativa — expira: {info.expires_label()}")
                self.after(300_000, self._license_heartbeat)
                return
            self.license_gate.logout()
        self.after(800, self.destroy)

    def _license_heartbeat(self):
        if self.license_locked or not self.license_gate or not self.license_gate.enabled:
            return
        try:
            info = self.license_gate.verify_active()
            self._update_license_sidebar(info)
        except KeyAuthError as exc:
            self._lock_license(str(exc))
            return
        self.after(300_000, self._license_heartbeat)

    def _ensure_license_ok(self) -> bool:
        if not self.license_gate or not self.license_gate.enabled:
            return True
        try:
            info = self.license_gate.verify_active()
            self._update_license_sidebar(info)
            return True
        except KeyAuthError as exc:
            self._lock_license(str(exc))
            return False

    def _persona_status_text(self):
        n = len(self.active_persona)
        if n == 0:
            return "VAZIA"
        return f"LIVE ({n})"

    def _update_persona_sidebar(self):
        if hasattr(self, "persona_status_label"):
            self.persona_status_label.configure(
                text=self._persona_status_text(),
                text_color=self.theme["accent"] if self.active_persona else self.theme["text_system"],
            )

    def apply_persona(self, text, notify=True, reset_chat=True):
        save_persona(text)
        self.active_persona = text
        self._update_persona_sidebar()
        if reset_chat:
            self._clear_chat(silent=True)
        if notify:
            preview = text[:100].replace("\n", " ").strip()
            if len(text) > 100:
                preview += "..."
            msg = (
                f"persona LIVE — {len(text)} chars — ativa AGORA.\n"
                f"preview: {preview or '(vazia)'}"
            )
            if reset_chat:
                msg += "\nchat zerado — historico antigo de recusas removido."
            self._append_system(msg)
        return True

    def _append_line(self, prefix, content, tag):
        self.chat_box.configure(state="normal")
        self.chat_box._textbox.insert("end", f"{prefix} ", "prefix")
        self.chat_box._textbox.insert("end", f"{content}\n\n", tag)
        self.chat_box.configure(state="disabled")
        self.chat_box._textbox.see("end")

    def _append_system(self, text):
        self._append_line("[SYS]", text, "system")

    def _append_error(self, text):
        self._append_line("[ERR]", text, "error")

    def _append_agent(self, text):
        self._append_line("[TRACE]", text, "agent")

    def _append_trace(self, text):
        """Log ao vivo do agent — visivel no chat."""
        self.after(0, lambda t=text: self._append_agent(t))

    def _restore_session(self):
        data = load_session()
        if not data or not data.get("history"):
            return
        self.session_id_value = data.get("id", self.session_id_value)
        self.history = data.get("history", [])
        for msg in self.history:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            images = msg.get("images") or []
            if role == "user":
                label = "[YOU]"
                if images:
                    content = (content or "(imagem)") + f"\n[{len(images)} print anexado]"
                self._append_line(label, content, "user")
            elif role == "assistant":
                name = self.config["assistant_name"].upper()
                self._append_line(f"[{name}]", content, "assistant")
        self.msg_count_label.configure(text=str(len(self.history)))
        self._append_system(f"sessao restaurada: {len(self.history)} mensagens.")

    def _update_preview(self):
        if not self.pending_images:
            self.preview_frame.pack_forget()
            return

        for child in self.preview_inner.winfo_children():
            child.destroy()

        self.preview_frame.pack(fill="x", padx=12, pady=(0, 4), before=self.input_frame)
        self.preview_inner.pack(fill="x", padx=8, pady=6)

        ctk.CTkLabel(
            self.preview_inner,
            text=f"{len(self.pending_images)} print(s) prontos",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color="#5a8a5a",
        ).pack(side="left", padx=(0, 8))

        try:
            thumb_raw = base64.b64decode(self.pending_images[-1])
            img = Image.open(io.BytesIO(thumb_raw))
            img.thumbnail((120, 80))
            self.preview_photo = ImageTk.PhotoImage(img)
            ctk.CTkLabel(self.preview_inner, image=self.preview_photo, text="").pack(side="left")
        except Exception:
            ctk.CTkLabel(self.preview_inner, text="[preview]", text_color="#5a8a5a").pack(side="left")

        ctk.CTkButton(
            self.preview_inner, text="X", width=28, height=24, command=self._clear_pending_images,
            fg_color="transparent", border_color="#1a3a1a", border_width=1,
            hover_color="#2a0a0a", text_color="#ff3333",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(side="right")

    def _clear_pending_images(self):
        self.pending_images = []
        self.preview_photo = None
        for child in self.preview_inner.winfo_children():
            child.destroy()
        self.preview_inner.pack_forget()
        self.preview_frame.pack_forget()

    def _attach_image(self):
        path = filedialog.askopenfilename(
            title="Selecionar imagem",
            filetypes=[
                ("Imagens", "*.png;*.jpg;*.jpeg;*.webp;*.bmp;*.gif"),
                ("Todos", "*.*"),
            ],
        )
        if not path:
            return
        try:
            encoded = load_image_file(path)
            self.pending_images.append(encoded)
            self._update_preview()
            self._append_system(f"print anexado: {Path(path).name}")
        except Exception as e:
            self._append_error(f"falha ao carregar imagem: {e}")

    def _on_paste(self, event=None):
        encoded = load_clipboard_image()
        if not encoded:
            return
        self.pending_images.append(encoded)
        self._update_preview()
        self._append_system("print colado do clipboard.")
        if self._focus_is_text_input():
            return "break"

    def _cancel_send(self):
        if not self.sending:
            return
        self._cancel_requested.set()
        resp = self._active_http_response
        if resp is not None:
            try:
                resp.close()
            except Exception:
                pass
        self._append_system("[ABORT] comando cancelado.")

    def _send(self, override_text=None, include_history=True):
        if self.sending:
            return
        if not self._ensure_license_ok():
            return

        text = (override_text if override_text is not None else self.input_box.get()).strip()
        images = list(self.pending_images)
        if not text and not images:
            return

        if override_text is None:
            self.input_box.delete(0, "end")
        self._clear_pending_images()

        self.sending = True
        self._cancel_requested.clear()
        self._set_generating_ui(True)

        display = text or "(analise o print)"
        if images:
            display += f"\n[{len(images)} print anexado]"
        self._append_line("[YOU]", display, "user")

        user_msg = {"role": "user", "content": text or "Descreva e analise a imagem anexada."}
        if images:
            user_msg["images"] = images
        self.history.append(user_msg)

        name = self.config["assistant_name"].upper()
        will_agent = self.config.get("agent_mode", True) and user_wants_agent_action(text)
        if will_agent:
            self._append_agent("▶ AGENT ON — analisando pedido...")
        else:
            self._append_line(f"[{name}]", "gerando resposta...", "assistant")
        self._processing_placeholder = not will_agent
        self._stream_started = False
        self._will_agent = will_agent

        thread = threading.Thread(
            target=self._chat_thread,
            kwargs={"include_history": include_history},
            daemon=True,
        )
        thread.start()

    def _review_chat(self):
        if not self.history:
            self._append_system("nada pra revisar ainda.")
            return
        prompt = (
            "Revise toda a conversa acima com atencao. Resuma o que foi discutido, "
            "liste pontos importantes, o que ficou pendente, e continue de onde paramos."
        )
        self._send(override_text=prompt, include_history=True)

    def _delete_all_sessions_confirm(self):
        count = len(list_sessions())
        if count == 0:
            self._append_system("nenhuma conversa salva pra apagar.")
            return
        if not messagebox.askyesno("Apagar conversas", f"Apagar {count} conversa(s) salva(s)? Isso nao apaga o chat atual."):
            return
        deleted = delete_all_sessions()
        self._append_system(f"{deleted} conversa(s) salva(s) apagada(s).")

    def _open_history(self):
        win = ctk.CTkToplevel(self)
        win.title("HISTORICO")
        win.geometry("720x560")
        win.configure(fg_color="#0a0f0a")
        win.grab_set()

        top = ctk.CTkFrame(win, fg_color="transparent")
        top.pack(fill="x", padx=16, pady=(12, 8))
        ctk.CTkLabel(
            top, text="> conversas salvas e sessao atual",
            font=ctk.CTkFont(family="Consolas", size=12), text_color="#00ff41",
        ).pack(side="left")

        def export_txt():
            path = filedialog.asksaveasfilename(
                defaultextension=".txt",
                filetypes=[("Texto", "*.txt")],
                initialfile=f"nyx-{self.session_id_value}.txt",
            )
            if not path:
                return
            lines = []
            for msg in self.history:
                role = msg.get("role", "?").upper()
                content = msg.get("content", "")
                images = msg.get("images") or []
                extra = f" [{len(images)} print(s)]" if images else ""
                lines.append(f"[{role}]{extra}\n{content}\n")
            Path(path).write_text("\n".join(lines), encoding="utf-8")
            self._append_system(f"chat exportado: {path}")

        ctk.CTkButton(
            top, text="EXPORTAR TXT", command=export_txt,
            fg_color="transparent", border_color="#006622", border_width=1,
            hover_color="#0d1a0d", text_color="#00ff41",
            font=ctk.CTkFont(family="Consolas", size=11),
        ).pack(side="right")

        body = ctk.CTkFrame(win, fg_color="#050805")
        body.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        left = ctk.CTkFrame(body, fg_color="#0a0f0a", width=220)
        left.pack(side="left", fill="y", padx=(0, 8))
        left.pack_propagate(False)

        sessions = list_sessions()
        current_item = {"id": self.session_id_value, "updated": "agora", "history": self.history, "_current": True}
        all_items = [current_item] + [s for s in sessions if s.get("id") != self.session_id_value]

        listbox = tk.Listbox(
            left, bg="#0d120d", fg="#b8ffb8", selectbackground="#1a3a1a",
            font=("Consolas", 10), borderwidth=0, highlightthickness=0,
        )
        listbox.pack(fill="both", expand=True, padx=8, pady=8)
        for item in all_items:
            tag = " (atual)" if item.get("_current") else ""
            listbox.insert("end", f"{item.get('id', '?')}{tag} | {len(item.get('history', []))} msgs")

        viewer = ctk.CTkTextbox(
            body, fg_color="#050805", text_color="#b8ffb8",
            font=ctk.CTkFont(family="Consolas", size=12), wrap="word",
        )
        viewer.pack(side="left", fill="both", expand=True)

        def show_selected(_event=None):
            idx = listbox.curselection()
            if not idx:
                return
            item = all_items[idx[0]]
            viewer.delete("1.0", "end")
            for msg in item.get("history", []):
                role = msg.get("role", "?").upper()
                content = msg.get("content", "")
                images = msg.get("images") or []
                extra = f" [{len(images)} print(s)]" if images else ""
                viewer.insert("end", f"[{role}]{extra}\n{content}\n\n")

        def load_selected():
            idx = listbox.curselection()
            if not idx:
                return
            item = all_items[idx[0]]
            if item.get("_current"):
                win.destroy()
                return
            self.history = item.get("history", [])
            self.session_id_value = item.get("id", session_id())
            self.chat_box.configure(state="normal")
            self.chat_box.delete("1.0", "end")
            self.chat_box.configure(state="disabled")
            for msg in self.history:
                role = msg.get("role")
                content = msg.get("content", "")
                images = msg.get("images") or []
                if role == "user":
                    if images:
                        content = (content or "(imagem)") + f"\n[{len(images)} print anexado]"
                    self._append_line("[YOU]", content, "user")
                elif role == "assistant":
                    self._append_line(f"[{self.config['assistant_name'].upper()}]", content, "assistant")
            self.msg_count_label.configure(text=str(len(self.history)))
            save_session(self.history, self.session_id_value)
            self._append_system(f"sessao carregada: {self.session_id_value}")
            win.destroy()

        def refresh_list():
            nonlocal sessions, all_items
            listbox.delete(0, "end")
            sessions = list_sessions()
            all_items = [current_item] + [s for s in sessions if s.get("id") != self.session_id_value]
            for item in all_items:
                tag = " (atual)" if item.get("_current") else ""
                listbox.insert("end", f"{item.get('id', '?')}{tag} | {len(item.get('history', []))} msgs")
            if all_items:
                listbox.selection_set(0)
                show_selected()

        def delete_selected():
            idx = listbox.curselection()
            if not idx:
                return
            item = all_items[idx[0]]
            if item.get("_current"):
                messagebox.showinfo("Historico", "Nao da pra apagar a sessao atual por aqui. Use CLEAR CHAT.")
                return
            sid = item.get("id")
            if not messagebox.askyesno("Apagar", f"Apagar conversa {sid}?"):
                return
            if delete_session(sid):
                self._append_system(f"conversa {sid} apagada.")
                refresh_list()

        def delete_all_saved():
            count = len(list_sessions())
            if count == 0:
                messagebox.showinfo("Historico", "Nenhuma conversa salva.")
                return
            if not messagebox.askyesno("Apagar todas", f"Apagar {count} conversa(s) salva(s)?"):
                return
            deleted = delete_all_sessions()
            self._append_system(f"{deleted} conversa(s) apagada(s).")
            refresh_list()

        listbox.bind("<<ListboxSelect>>", show_selected)
        if all_items:
            listbox.selection_set(0)
            show_selected()

        footer = ctk.CTkFrame(win, fg_color="transparent")
        footer.pack(fill="x", padx=16, pady=(0, 12))
        ctk.CTkButton(
            footer, text="EXCLUIR SELECIONADA", command=delete_selected,
            fg_color="transparent", border_color="#3a1a1a", border_width=1,
            hover_color="#1a0d0d", text_color="#ff6666",
            font=ctk.CTkFont(family="Consolas", size=11),
        ).pack(side="left")
        ctk.CTkButton(
            footer, text="EXCLUIR TODAS", command=delete_all_saved,
            fg_color="transparent", border_color="#3a1a1a", border_width=1,
            hover_color="#1a0d0d", text_color="#ff6666",
            font=ctk.CTkFont(family="Consolas", size=11),
        ).pack(side="left", padx=(8, 0))
        ctk.CTkButton(
            footer, text="CARREGAR SESSAO", command=load_selected,
            fg_color="transparent", border_color="#006622", border_width=1,
            hover_color="#0d1a0d", text_color="#00ff41",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(side="right")

    def _last_user_message(self) -> str:
        for msg in reversed(self.history):
            if msg.get("role") != "user":
                continue
            content = (msg.get("content") or "").strip()
            if not content or content.startswith("Resultados das ferramentas:"):
                continue
            return content
        return ""

    def _chat_thread(self, include_history=True):
        try:
            use_agent = getattr(self, "_will_agent", False)
            if use_agent and self.config.get("agent_mode", True):
                reply = self._call_ai_agent(include_history=include_history)
            else:
                reply = self._call_ai(include_history=include_history)
            if self._cancel_requested.is_set():
                raise ChatCancelled()
            self.after(0, lambda: self._finish_reply(reply, None))
        except ChatCancelled:
            self.after(0, lambda: self._finish_reply(None, None, cancelled=True))
        except Exception as e:
            if self._cancel_requested.is_set():
                self.after(0, lambda: self._finish_reply(None, None, cancelled=True))
            else:
                self.after(0, lambda: self._finish_reply(None, str(e)))

    def _build_api_messages(self, history):
        api_messages = []
        for msg in history:
            item = {"role": msg["role"], "content": msg.get("content", "")}
            if msg.get("images"):
                item["images"] = msg["images"]
            api_messages.append(item)
        return api_messages

    def _ollama_model_for(self, has_images: bool) -> str:
        if has_images:
            return self.config.get("ollama_vision_model", "llava:7b")
        return self.config["ollama_model"]

    def _build_system_messages(self, raw_persona: str, with_agent: bool) -> list[dict]:
        core = build_intelligence_system(raw_persona)
        msgs = [{"role": "system", "content": core}]
        if with_agent:
            home = Path.home()
            desktop = home / "Desktop"
            if not desktop.exists():
                desktop = home / "Área de Trabalho"
            ws = str(WORKSPACE_DIR)
            msgs.append({
                "role": "system",
                "content": (
                    AGENT_LAYER
                    + f"\n\nPC do usuario:"
                    + f"\n- Home: {home}"
                    + f"\n- Desktop: {desktop}"
                    + f"\n- NYX workspace: {ws}"
                    + f"\n- Downloads: {home / 'Downloads'}"
                    + "\n\nNavegador: use browser_navigate + browser_snapshot pra interagir em sites (desenho, forms, etc)."
                    + build_ce_agent_layer(self.config)
                ),
            })
        return msgs

    def _ollama_options(self, mode: str = "chat") -> dict:
        intel_max = self.config.get("intelligence_max", True)
        if mode == "agent":
            return {
                "temperature": 0.35,
                "top_p": 0.9,
                "top_k": 40,
                "repeat_penalty": 1.1,
                "num_ctx": 8192,
                "num_predict": 1536,
            }
        if intel_max:
            return {
                "temperature": 0.42,
                "top_p": 0.88,
                "top_k": 60,
                "repeat_penalty": 1.05,
                "num_ctx": 8192,
                "num_predict": 3072,
            }
        return {
            "temperature": 0.65,
            "top_p": 0.92,
            "top_k": 50,
            "repeat_penalty": 1.08,
            "num_ctx": 4096,
            "num_predict": 2048,
        }

    def _queue_stream_token(self, piece: str):
        if not piece:
            return
        self.after(0, lambda p=piece: self._on_stream_piece(p))

    def _on_stream_piece(self, piece: str):
        if not piece:
            return
        self.chat_box.configure(state="normal")
        if not self._stream_started:
            content = self.chat_box.get("1.0", "end")
            if "gerando resposta..." in content:
                lines = [ln for ln in content.split("\n") if "gerando resposta..." not in ln]
                self.chat_box.delete("1.0", "end")
                self.chat_box.insert("1.0", "\n".join(lines).rstrip() + "\n\n")
            name = self.config["assistant_name"].upper()
            self.chat_box._textbox.insert("end", f"[{name}] ", "prefix")
            self._stream_started = True
            self._processing_placeholder = False
        self.chat_box._textbox.insert("end", piece, "assistant")
        self.chat_box._textbox.see("end")
        self.chat_box.configure(state="disabled")

    def _ollama_chat(
        self,
        messages: list,
        model: str,
        mode: str = "chat",
        temperature: float | None = None,
        num_predict: int | None = None,
        num_ctx: int | None = None,
        on_token=None,
    ) -> str:
        url = f"{self.config['ollama_url'].rstrip('/')}/api/chat"
        opts = self._ollama_options(mode)
        if temperature is not None:
            opts["temperature"] = temperature
        if num_predict is not None:
            opts["num_predict"] = num_predict
        if num_ctx is not None:
            opts["num_ctx"] = num_ctx
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,
            "think": False,
            "options": opts,
        }
        resp = requests.post(url, json=payload, stream=True, timeout=900)
        if resp.status_code == 400:
            payload.pop("think", None)
            resp = requests.post(url, json=payload, stream=True, timeout=900)
        if not resp.ok:
            raise ValueError(resp.text)

        self._active_http_response = resp
        chunks: list[str] = []
        try:
            for raw in resp.iter_lines():
                if self._cancel_requested.is_set():
                    raise ChatCancelled()
                if not raw:
                    continue
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                msg = data.get("message") or {}
                piece = msg.get("content") or ""
                if piece:
                    chunks.append(piece)
                    if on_token:
                        on_token(piece)
                if data.get("error"):
                    raise ValueError(str(data["error"]))
            return clean_model_output("".join(chunks))
        finally:
            self._active_http_response = None
            try:
                resp.close()
            except Exception:
                pass

    def _call_ai_agent(self, include_history=True) -> str:
        if self.config["provider"] != "ollama":
            return self._call_ai(include_history=include_history)

        raw_persona = self.active_persona
        history = self.history if include_history else self.history[-1:]
        has_images = any(m.get("images") for m in history)
        model = self._ollama_model_for(has_images)

        messages = [
            *self._build_system_messages(raw_persona, with_agent=True),
            *self._build_api_messages(history[-self.config["max_history"]:]),
        ]

        def on_step(tool, args, result):
            if not self.config.get("agent_show_trace", True):
                return
            if tool == "__think__":
                p = (args or {}).get("passo", "?")
                m = (args or {}).get("max", "?")
                self.after(0, lambda: self._append_agent(f"◆ passo {p}/{m} — consultando modelo..."))
                return
            if tool == "__plan__":
                self.after(0, lambda r=result: self._append_agent(f"◆ {r}"))
                return
            try:
                args_preview = json.dumps(args or {}, ensure_ascii=False)
            except TypeError:
                args_preview = str(args)
            if len(args_preview) > 400:
                args_preview = args_preview[:400] + "..."
            preview = (result or "").strip() or "(sem output)"
            if len(preview) > 1800:
                preview = preview[:1800] + "\n...(truncado)"
            block = f"▶ {tool}\n  args: {args_preview}\n  result:\n{preview}"
            self.after(0, lambda b=block: self._append_agent(b))

        def chat_fn(msgs):
            return self._ollama_chat(msgs, model, mode="agent")

        last_user = ""
        for msg in reversed(history):
            if msg.get("role") == "user" and msg.get("content"):
                c = msg["content"]
                if not c.startswith("Resultados das ferramentas:"):
                    last_user = c
                    break

        if not user_wants_agent_action(last_user):
            return self._call_ai(include_history=include_history)

        return run_agent_loop(
            chat_fn,
            messages,
            WORKSPACE_DIR,
            max_steps=8,
            on_step=on_step,
            user_context=last_user,
            ce_config=self.config,
            app_dir=APP_DIR,
            cancel_check=self._cancel_requested.is_set,
        )

    def _call_ai(self, include_history=True):
        raw_persona = self.active_persona
        system_prompt = build_system_prompt(raw_persona)
        history = self.history if include_history else self.history[-1:]
        has_images = any(m.get("images") for m in history)

        if self.config["provider"] == "ollama":
            model = self._ollama_model_for(has_images)
            last_user = self._last_user_message()
            messages = [
                *self._build_system_messages(system_prompt, with_agent=False),
                *self._build_api_messages(history[-self.config["max_history"]:]),
            ]
            messages = enrich_messages_for_depth(
                messages, last_user, self.config.get("intelligence_max", True),
            )
            return self._ollama_chat(
                messages, model, mode="chat", on_token=self._queue_stream_token,
            )

        if self.config["provider"] == "anthropic":
            if not self.config.get("anthropic_key"):
                raise ValueError("API key da Anthropic nao configurada. Va em CONFIG e cole sua chave.")
            anthropic_messages = []
            for msg in history[-self.config["max_history"]:]:
                content = []
                if msg.get("content"):
                    content.append({"type": "text", "text": msg["content"]})
                for img_b64 in msg.get("images") or []:
                    content.append({
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/jpeg",
                            "data": img_b64,
                        },
                    })
                if not content:
                    content = [{"type": "text", "text": "(imagem)"}]
                anthropic_messages.append({"role": msg["role"], "content": content})
            resp = requests.post(
                self.config.get("anthropic_url", "https://api.anthropic.com/v1/messages"),
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": self.config["anthropic_key"],
                    "anthropic-version": "2023-06-01",
                },
                json={
                    "model": self.config.get("anthropic_model", "claude-opus-4-8"),
                    "max_tokens": 8192,
                    "system": build_intelligence_system(system_prompt),
                    "messages": anthropic_messages,
                    "temperature": 0.5,
                },
                timeout=240,
            )
            if not resp.ok:
                raise ValueError(resp.text)
            data = resp.json()
            return data["content"][0]["text"]

        messages = [{"role": "system", "content": build_intelligence_system(system_prompt)}]
        for msg in history[-self.config["max_history"]:]:
            if msg.get("images"):
                parts = [{"type": "text", "text": msg.get("content") or "Descreva a imagem."}]
                for img_b64 in msg["images"]:
                    parts.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"},
                    })
                messages.append({"role": msg["role"], "content": parts})
            else:
                messages.append({"role": msg["role"], "content": msg.get("content", "")})
        resp = requests.post(
            self.config["api_url"],
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.config['api_key']}",
            },
            json={
                "model": self.config["api_model"],
                "messages": messages,
                "temperature": 0.85,
            },
            timeout=240,
        )
        if not resp.ok:
            raise ValueError(resp.text)
        return resp.json()["choices"][0]["message"]["content"]

    def _finish_reply(self, reply, error, *, cancelled=False):
        streamed = getattr(self, "_stream_started", False)
        if getattr(self, "_processing_placeholder", False) and not streamed:
            self.chat_box.configure(state="normal")
            content = self.chat_box.get("1.0", "end")
            if "gerando resposta..." in content:
                lines = [ln for ln in content.split("\n") if "gerando resposta..." not in ln]
                self.chat_box.delete("1.0", "end")
                self.chat_box.insert("1.0", "\n".join(lines).rstrip() + "\n\n")
            self.chat_box.configure(state="disabled")

        if cancelled:
            if streamed:
                self.chat_box.configure(state="normal")
                self.chat_box._textbox.insert("end", "\n[cancelado]\n\n", "system")
                self.chat_box.configure(state="disabled")
            elif self.history and self.history[-1].get("role") == "user":
                self.history.pop()
            self.status_label.configure(text="● ONLINE", text_color=self.theme["accent"])
            save_session(self.history, self.session_id_value)
        elif error:
            self._append_error(error)
            self.status_label.configure(text="● ERROR", text_color="#ff3333")
            save_session(self.history, self.session_id_value)
        else:
            if streamed:
                self.chat_box.configure(state="normal")
                self.chat_box._textbox.insert("end", "\n\n", "assistant")
                self.chat_box.configure(state="disabled")
                self.chat_box._textbox.see("end")
            else:
                if getattr(self, "_will_agent", False) and self.config.get("agent_show_trace", True):
                    self._append_agent("■ execucao concluida — resposta final:")
                name = self.config["assistant_name"].upper()
                self._append_line(f"[{name}]", reply, "assistant")
            self.history.append({"role": "assistant", "content": reply})
            self.status_label.configure(text="● ONLINE", text_color=self.theme["accent"])
            save_session(self.history, self.session_id_value)

        self.msg_count_label.configure(text=str(len(self.history)))
        self.sending = False
        self._cancel_requested.clear()
        self._set_generating_ui(False)
        self._processing_placeholder = False
        self._stream_started = False
        self._will_agent = False
        self.input_box.focus()

    def _clear_chat(self, silent=False):
        self.history = []
        self.pending_images = []
        self._clear_pending_images()
        self.session_id_value = session_id()
        self.chat_box.configure(state="normal")
        self.chat_box.delete("1.0", "end")
        self.chat_box.configure(state="disabled")
        if not silent:
            self._append_system("chat cleared. nova sessao iniciada.")
        self.msg_count_label.configure(text="0")
        save_session(self.history, self.session_id_value)

    def _open_config(self):
        win = ctk.CTkToplevel(self)
        win.title("CONFIG")
        win.geometry("440x680")
        win.configure(fg_color="#0a0f0a")
        win.grab_set()

        fields = {}

        def add_field(label, key, default="", password=False):
            ctk.CTkLabel(win, text=label, font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
            entry = ctk.CTkEntry(win, fg_color="#0d120d", border_color="#1a3a1a", text_color="#b8ffb8", show="*" if password else "")
            entry.insert(0, str(self.config.get(key, default)))
            entry.pack(fill="x", padx=20)
            fields[key] = entry

        add_field("Assistant Name", "assistant_name", "BG MODS IA")

        ctk.CTkLabel(win, text="Provider", font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
        provider = ctk.CTkComboBox(win, values=["anthropic", "ollama", "api"], fg_color="#0d120d", border_color="#1a3a1a")
        provider.set(self.config["provider"])
        provider.pack(fill="x", padx=20)

        add_field("Anthropic Model", "anthropic_model", "claude-opus-4-8")
        add_field("Anthropic API Key", "anthropic_key", "", password=True)

        add_field("Ollama URL", "ollama_url", "http://localhost:11434")

        ctk.CTkLabel(win, text="Modelo uncensored (preset)", font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
        preset = ctk.CTkComboBox(win, values=list(OLLAMA_PRESETS.keys()), fg_color="#0d120d", border_color="#1a3a1a")
        current = self.config.get("ollama_model", "dolphin3:8b")
        preset_label = next((k for k, v in OLLAMA_PRESETS.items() if v == current), list(OLLAMA_PRESETS.keys())[1])
        preset.set(preset_label)
        preset.pack(fill="x", padx=20)

        add_field("Ollama Model (manual)", "ollama_model", "dolphin3:8b")

        def on_preset_change(choice):
            fields["ollama_model"].delete(0, "end")
            fields["ollama_model"].insert(0, OLLAMA_PRESETS[choice])

        preset.configure(command=on_preset_change)

        ctk.CTkLabel(win, text="Modelo vision (prints)", font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
        vision_preset = ctk.CTkComboBox(win, values=list(OLLAMA_VISION_PRESETS.keys()), fg_color="#0d120d", border_color="#1a3a1a")
        current_vision = self.config.get("ollama_vision_model", "llava:7b")
        vision_label = next((k for k, v in OLLAMA_VISION_PRESETS.items() if v == current_vision), list(OLLAMA_VISION_PRESETS.keys())[0])
        vision_preset.set(vision_label)
        vision_preset.pack(fill="x", padx=20)
        add_field("Vision Model (manual)", "ollama_vision_model", "llava:7b")

        def on_vision_preset_change(choice):
            fields["ollama_vision_model"].delete(0, "end")
            fields["ollama_vision_model"].insert(0, OLLAMA_VISION_PRESETS[choice])

        vision_preset.configure(command=on_vision_preset_change)

        add_field("API URL", "api_url", "https://api.openai.com/v1/chat/completions")
        add_field("API Key", "api_key", "", password=True)
        add_field("API Model", "api_model", "gpt-4o-mini")

        ctk.CTkLabel(win, text="Agent mode (mexe no PC)", font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
        agent_switch = ctk.CTkSwitch(win, text="AGENT ON — executa no PC (sempre ativo quando ligado)")
        if self.config.get("agent_mode", True):
            agent_switch.select()
        agent_switch.pack(anchor="w", padx=20)

        trace_switch = ctk.CTkSwitch(win, text="TRACE ON — mostra tudo que o agent faz")
        if self.config.get("agent_show_trace", True):
            trace_switch.select()
        trace_switch.pack(anchor="w", padx=20, pady=(4, 0))

        ctk.CTkLabel(win, text="Cheat Engine MCP", font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
        ce_switch = ctk.CTkSwitch(win, text="CE MCP ON — memoria / scan via Cheat Engine")
        if self.config.get("ce_mcp_enabled", False):
            ce_switch.select()
        ce_switch.pack(anchor="w", padx=20)
        add_field("CE MCP script (vazio = padrao)", "ce_mcp_script", "")

        ctk.CTkLabel(win, text="Inteligencia", font=ctk.CTkFont(family="Consolas", size=11), text_color="#5a8a5a").pack(anchor="w", padx=20, pady=(12, 2))
        intel_switch = ctk.CTkSwitch(win, text="INTELIGENCIA ALTA — raciocinio profundo + contexto 32k")
        if self.config.get("intelligence_max", True):
            intel_switch.select()
        intel_switch.pack(anchor="w", padx=20)

        def save():
            self.config["assistant_name"] = fields["assistant_name"].get().strip() or APP_BRAND
            self.config["provider"] = provider.get()
            self.config["agent_mode"] = bool(agent_switch.get())
            self.config["agent_show_trace"] = bool(trace_switch.get())
            self.config["intelligence_max"] = bool(intel_switch.get())
            self.config["ce_mcp_enabled"] = bool(ce_switch.get())
            self.config["ce_mcp_script"] = fields["ce_mcp_script"].get().strip()
            self.config["anthropic_model"] = fields["anthropic_model"].get().strip() or "claude-opus-4-8"
            self.config["anthropic_key"] = fields["anthropic_key"].get().strip()
            self.config["ollama_url"] = fields["ollama_url"].get().strip()
            self.config["ollama_model"] = fields["ollama_model"].get().strip()
            self.config["ollama_vision_model"] = fields["ollama_vision_model"].get().strip() or "llava:7b"
            self.config["api_url"] = fields["api_url"].get().strip()
            self.config["api_key"] = fields["api_key"].get().strip()
            self.config["api_model"] = fields["api_model"].get().strip()
            save_config(self.config)
            self._append_system(
                f"config saved. engine: {APP_BRAND} | "
                f"agent: {'ON' if self.config.get('agent_mode') else 'OFF'} | "
                f"ce_mcp: {'ON' if self.config.get('ce_mcp_enabled') else 'OFF'}."
            )
            win.destroy()

        ctk.CTkButton(
            win, text="SAVE & CONNECT", command=save,
            fg_color="transparent", border_color="#006622", border_width=1,
            hover_color="#0d1a0d", text_color="#00ff41",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(pady=20)

    def _open_persona(self):
        if self._persona_editor_win and self._persona_editor_win.winfo_exists():
            self._persona_editor_win.lift()
            self._persona_editor_win.focus()
            return

        win = ctk.CTkToplevel(self)
        self._persona_editor_win = win
        win.title("PERSONA EDITOR — RAW LIVE")
        win.geometry("800x680")
        win.configure(fg_color="#0a0f0a")
        win.grab_set()

        def on_close():
            if self._persona_autosave_job:
                self.after_cancel(self._persona_autosave_job)
                self._persona_autosave_job = None
            self._persona_editor_win = None
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", on_close)

        top = ctk.CTkFrame(win, fg_color="transparent")
        top.pack(fill="x", padx=20, pady=(16, 4))

        ctk.CTkLabel(
            top,
            text="LIVE SYNC — salva e aplica na hora, sem reiniciar",
            font=ctk.CTkFont(family="Consolas", size=11),
            text_color="#00ff41",
        ).pack(side="left")

        live_label = ctk.CTkLabel(
            top,
            text="SYNC: aguardando",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color="#5a8a5a",
        )
        live_label.pack(side="right", padx=(8, 0))

        btn_row = ctk.CTkFrame(top, fg_color="transparent")
        btn_row.pack(side="right")

        editor_frame = ctk.CTkFrame(win, fg_color="#0d120d", border_color="#1a3a1a", border_width=1)
        editor_frame.pack(fill="both", expand=True, padx=20, pady=8)

        scrollbar = tk.Scrollbar(editor_frame)
        scrollbar.pack(side="right", fill="y")

        editor = tk.Text(
            editor_frame,
            bg="#0d120d",
            fg="#b8ffb8",
            insertbackground="#00ff41",
            selectbackground="#1a3a1a",
            font=("Consolas", 12),
            wrap="word",
            borderwidth=0,
            highlightthickness=0,
            yscrollcommand=scrollbar.set,
            undo=True,
            maxundo=-1,
        )
        editor.pack(side="left", fill="both", expand=True, padx=8, pady=8)
        scrollbar.config(command=editor.yview)

        current = self.active_persona
        if current:
            editor.insert("1.0", current)

        char_label = ctk.CTkLabel(
            win,
            text=f"{len(current)} chars | LIVE | {PERSONA_FILE}",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color="#5a8a5a",
        )
        char_label.pack(anchor="w", padx=20)

        last_saved = {"text": current}

        def update_count(_event=None):
            n = len(editor.get("1.0", "end-1c"))
            char_label.configure(text=f"{n} chars | LIVE | {PERSONA_FILE}")
            schedule_autosave()

        def schedule_autosave():
            if self._persona_autosave_job:
                self.after_cancel(self._persona_autosave_job)

            def autosave():
                text = editor.get("1.0", "end-1c")
                if text == last_saved["text"]:
                    live_label.configure(text="SYNC: ok", text_color="#00ff41")
                    return
                save_persona(text)
                self.active_persona = text
                last_saved["text"] = text
                self._update_persona_sidebar()
                live_label.configure(text=f"SYNC: live ({len(text)})", text_color="#00ff41")

            self._persona_autosave_job = self.after(800, autosave)
            live_label.configure(text="SYNC: editando...", text_color="#ffaa00")

        editor.bind("<<Modified>>", lambda e: (update_count(), editor.edit_modified(False)))
        editor.bind("<KeyRelease>", lambda e: schedule_autosave())

        def paste_clipboard():
            try:
                clip = win.clipboard_get()
            except tk.TclError:
                return
            editor.insert("insert", clip)
            update_count()

        def import_file():
            path = filedialog.askopenfilename(
                title="Importar persona",
                filetypes=[("Todos", "*.*"), ("Texto", "*.txt"), ("Markdown", "*.md")],
            )
            if not path:
                return
            try:
                text = Path(path).read_bytes().decode("utf-8", errors="replace")
                editor.delete("1.0", "end")
                editor.insert("1.0", text)
                update_count()
                self.apply_persona(text, notify=False)
                last_saved["text"] = text
                live_label.configure(text=f"SYNC: live ({len(text)})", text_color="#00ff41")
                self._append_system(f"persona importada: {Path(path).name} ({len(text)} chars) — LIVE")
            except Exception as e:
                messagebox.showerror("Erro", f"Falha ao importar: {e}")

        def save(close=False):
            text = editor.get("1.0", "end-1c")
            if load_persona() != text:
                save_persona(text)
            if load_persona() != text:
                messagebox.showerror(
                    "Erro ao salvar",
                    f"persona nao bateu apos salvar.\n"
                    f"editor: {len(text)} chars\n"
                    f"disco: {len(load_persona())} chars",
                )
                return False
            self.apply_persona(text, notify=True)
            last_saved["text"] = text
            live_label.configure(text=f"SYNC: live ({len(text)})", text_color="#00ff41")
            if close:
                on_close()
            return True

        def save_and_close():
            save(close=True)

        def apply_only():
            save(close=False)

        ctk.CTkButton(
            btn_row, text="COLAR", command=paste_clipboard, width=70,
            fg_color="transparent", border_color="#1a3a1a", border_width=1,
            hover_color="#0d1a0d", text_color="#00ffcc",
            font=ctk.CTkFont(family="Consolas", size=11),
        ).pack(side="left", padx=2)

        ctk.CTkButton(
            btn_row, text="IMPORTAR", command=import_file, width=90,
            fg_color="transparent", border_color="#1a3a1a", border_width=1,
            hover_color="#0d1a0d", text_color="#00ffcc",
            font=ctk.CTkFont(family="Consolas", size=11),
        ).pack(side="left", padx=2)

        footer = ctk.CTkFrame(win, fg_color="transparent")
        footer.pack(fill="x", padx=20, pady=12)

        ctk.CTkButton(
            footer, text="APLICAR (LIVE)", command=apply_only,
            fg_color="transparent", border_color="#1a3a1a", border_width=1,
            hover_color="#0d1a0d", text_color="#00ffcc",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(side="right", padx=(8, 0))

        ctk.CTkButton(
            footer, text="SAVE & FECHAR", command=save_and_close,
            fg_color="transparent", border_color="#006622", border_width=1,
            hover_color="#0d1a0d", text_color="#00ff41",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(side="right")


def main():
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")

    ka_cfg = load_keyauth_app_config(APP_DIR)
    manifest_url = (ka_cfg.get("update_manifest_url") or "").strip()
    if manifest_url:
        updated, msg = check_and_apply(APP_DIR, manifest_url)
        if updated:
            ka_cfg = load_keyauth_app_config(APP_DIR)

    gate = LicenseGate(APP_DIR, USER_DATA_DIR)

    if ka_cfg.get("enabled"):
        try:
            info = gate.authenticate()
        except KeyAuthError as exc:
            messagebox.showerror(f"{APP_BRAND} License", str(exc))
            return
        if not info:
            return
    else:
        gate.enabled = False

    app = NyxApp(license_gate=gate)
    app.mainloop()


if __name__ == "__main__":
    main()
