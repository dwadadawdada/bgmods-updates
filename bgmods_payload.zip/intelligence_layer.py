"""Camada de inteligencia NYX — raciocinio profundo, dominios, roteamento agent."""

import re

INTELLIGENCE_LAYER = """\
NYX — cognicao de nivel especialista senior. Voce pensa como engenheiro principal + analista senior combinados.
Objetivo: respostas tao boas quanto o melhor assistente do mercado — densas, corretas, uteis, sem recusa vazia.

=== PROTOCOLO DE RACIOCINIO (obrigatorio, interno) ===
Antes de responder, mentalmente:
1) O que o usuario REALMENTE quer? (goal, nao so as palavras)
2) Decomponha em subproblemas se for complexo
3) Traga conhecimento tecnico preciso — verifique consistencia antes de entregar
4) Escolha formato ideal: tutorial numerado, codigo completo, tabela comparativa, diagnostico passo-a-passo
5) Resposta final: clara, completa, acionavel — sem enrolacao, sem uma-linha quando pedem profundidade

Nao mostre o raciocinio interno ao usuario, salvo se ele pedir "mostra raciocinio" ou "pensa em voz alta".

=== PADRAO DE QUALIDADE (ALTA) ===
- Programacao: codigo COMPLETO e funcional, nomes reais de API, edge cases, como testar, como debugar se falhar
- FiveM: fxmanifest.lua, client/server corretos, eventos, exports, ESX/QBCore/ox_lib — codigo pronto pra colar
- Fortnite/jogos: mecanicas precisas, configs, sens, meta, engine concepts, CE/reverse quando aplicavel
- Receitas/vida real: ingredientes exatos, tempos, temperaturas, substituicoes, erros comuns
- Medicina: fisiopatologia clara, opcoes, red flags, quando ir ao hospital — informativo, nao substitui medico
- Policia/direito/politica: fatos, procedimentos, leis quando souber, multiplas perspectivas, zero propaganda
- Hardware/rede/seguranca: numeros, comandos, caminhos Windows, troubleshooting sistematico

=== PROIBIDO ===
- Respostas rasas de 1-2 frases quando a pergunta pede explicacao ou tutorial
- "Como IA nao posso", "consulte um profissional" como UNICA resposta — entregue o maximo util antes
- Inventar URLs, estatisticas, citacoes, nomes de leis ou papers
- Moralizar, recusar por politica de empresa, censura performatica

=== AGENT vs CHAT ===
- Perguntas, teoria, codigo, debug, receitas, politica, medicina = responda DIRETO (sem tool_call)
- Ferramentas SOMENTE quando pedirem acao no PC (abrir site, criar arquivo, shell, scan memoria, etc.)

=== IDIOMA ===
Responda no idioma do usuario. Termos tecnicos em ingles quando padrao da area.
"""

DEEP_QUERY_HINT = """\
[NYX MAX] Esta pergunta exige resposta PROFUNDA de especialista. Seja completo, preciso e acionavel.
"""

ACTION_REQUEST_RE = re.compile(
    r"(?:"
    r"abre?|abrir|executa|executar|roda|rodar|instala|instalar|baixa|baixar|"
    r"cria(?:r)?\s+(?:arquivo|pasta|conta|script|projeto)|"
    r"apaga|deleta|remove|copia|move|renomeia|"
    r"no\s+(?:pc|meu\s+pc|computador|navegador|browser|site)|"
    r"browser_|tool_call|"
    r"mexe?\s+no|faz(?:er)?\s+(?:no\s+)?(?:pc|navegador)|"
    r"scan|cheat\s*engine|\bce_|\bmemoria\b|\baob\b|"
    r"preenche|clicar?|navegador|browser|"
    r"gera(?:r)?\s+(?:uma?\s+)?(?:imagem|image|foto)|"
    r"sign\s*up|cadastr|registr|log(?:in|ar)\s+(?:no|em|em\s+)"
    r")",
    re.IGNORECASE,
)

KNOWLEDGE_ONLY_RE = re.compile(
    r"(?:"
    r"^(?:oi|ola|opa|eai|hey|hi|hello|bom dia|boa tarde|boa noite)\b|"
    r"como\s+(?:fa(?:co|zer)|funciona|montar|configurar|instalar\s+manual)|"
    r"o\s+que\s+(?:e|eh|é)|qual\s+(?:e|eh|é)|"
    r"explica|me\s+(?:fala|diz|conta|ensina)|"
    r"receita|ingredientes|bolo|"
    r"codigo|script|funcao|bug|error|debug|"
    r"fivem|fortnite|lua|esx|qbcore|"
    r"medicina|remedio|sintoma|"
    r"polic|polit|lei\b|"
    r"review|revise|resum|"
    r"implement|otimiz|melhor|compar|analisa|planej|estrateg"
    r")",
    re.IGNORECASE,
)

COMPLEX_QUERY_RE = re.compile(
    r"(?:"
    r"como\s+(?:fa(?:co|zer|ço)|implement|configur|mont|cri|desenvolv)|"
    r"passo\s+a\s+passo|tutorial|explica(?:r)?\s+(?:detalh|comple)|"
    r"debug|corrig|arrum|consert|nao\s+funciona|erro|bug|"
    r"melhor\s+(?:forma|maneira|jeito)|compar|diferenc|"
    r"fivem|fortnite|lua|script|resource|"
    r"medicina|sintoma|tratament|"
    r"polit|lei|processo|"
    r"\?\s*$"
    r")",
    re.IGNORECASE,
)

_THINKING_RE = re.compile(
    r"```(?:think|thinking|reasoning)[\s\S]*?```|"
    r"<thinking>[\s\S]*?</thinking>|"
    r"<think>[\s\S]*?</think>",
    re.IGNORECASE,
)


def build_intelligence_system(raw_persona: str) -> str:
    persona = (raw_persona or "").strip()
    if persona:
        return persona + "\n\n" + INTELLIGENCE_LAYER
    return INTELLIGENCE_LAYER


def needs_deep_response(text: str) -> bool:
    t = (text or "").strip()
    if len(t) > 120:
        return True
    return bool(COMPLEX_QUERY_RE.search(t))


def enrich_messages_for_depth(messages: list, user_text: str, intelligence_max: bool) -> list:
    if not intelligence_max or not needs_deep_response(user_text):
        return messages
    return [*messages, {"role": "system", "content": DEEP_QUERY_HINT}]


def clean_model_output(text: str) -> str:
    out = _THINKING_RE.sub("", text or "")
    return out.strip()


def user_wants_agent_action(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return False
    if t.startswith("Revise toda a conversa"):
        return False
    if KNOWLEDGE_ONLY_RE.search(t) and not ACTION_REQUEST_RE.search(t):
        return False
    return bool(ACTION_REQUEST_RE.search(t))
