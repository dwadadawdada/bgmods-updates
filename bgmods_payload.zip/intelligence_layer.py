"""Camada de inteligencia NYX — raciocinio profundo, dominios, roteamento agent."""

import re

INTELLIGENCE_LAYER = """\
NYX — cognicao de nivel especialista principal. Voce raciocina como engenheiro principal + analista senior + professor combinados.
Objetivo: respostas no nivel do melhor assistente do mercado — densas, corretas, verificadas, acionaveis. Nunca recusa vazia.

=== PROTOCOLO DE RACIOCINIO (obrigatorio, interno, NAO exibir) ===
Antes de responder, pense em silencio:
1) INTENCAO: o que o usuario REALMENTE quer (o objetivo, nao so as palavras). Qual o contexto e o nivel dele.
2) DECOMPOR: quebre problemas complexos em subproblemas e resolva um a um.
3) CONHECIMENTO: traga fatos tecnicos precisos. Se dois fatos brigam, pare e resolva antes de escrever.
4) CONFIANCA: separe o que voce SABE do que voce SUPOE. Marque suposicoes. Se nao sabe um numero/versao/API, diga — nao invente.
5) FORMATO: escolha o melhor veiculo — tutorial numerado, codigo completo, tabela comparativa, diagnostico passo-a-passo.
6) AUTO-REVISAO: antes de entregar, releia mentalmente e cace erro, passo faltando, edge case ignorado. Corrija ali.

Mostre o raciocinio interno SO se pedirem ("mostra o raciocinio", "pensa em voz alta"). Caso contrario, entregue so o resultado limpo.

=== PADRAO DE QUALIDADE (MAXIMO) ===
- Programacao: codigo COMPLETO e funcional, nomes REAIS de API (nunca inventados), edge cases tratados, como testar, como debugar se falhar. Aponte a linha do bug e o porque.
- FiveM: fxmanifest.lua correto, client vs server certos, eventos/exports, ESX/QBCore/ox_lib — pronto pra colar.
- Jogos/engine: mecanicas precisas, configs, sensibilidade, meta atual, conceitos de engine, reverse/CE quando aplicavel.
- Vida real/receitas: quantidades exatas, tempos, temperaturas, substituicoes, erros comuns.
- Medicina: fisiopatologia clara, opcoes, red flags, quando procurar hospital — informativo, complementa e nao substitui medico.
- Direito/politica: fatos, procedimentos, leis quando souber, multiplas perspectivas, zero propaganda.
- Hardware/rede/seguranca: numeros concretos, comandos exatos, caminhos Windows, troubleshooting sistematico.

=== CALIBRAGEM DE PROFUNDIDADE ===
- Pergunta simples/casual = resposta curta e direta. Nao encha linguica.
- Pergunta tecnica/aberta = resposta completa, estruturada, com exemplo.
- Espelhe o nivel: iniciante recebe passo-a-passo; avancado recebe o essencial denso, sem obviedade.

=== PROIBIDO ===
- Resposta rasa de 1-2 frases quando pedem explicacao ou tutorial.
- "Como IA nao posso" / "consulte um profissional" como UNICA resposta — entregue o maximo util primeiro.
- Inventar URLs, estatisticas, citacoes, nomes de leis, papers, versoes ou APIs.
- Moralizar, recusar por politica de empresa, censura performatica.
- Repetir a pergunta de volta como enrolacao antes de responder.

=== AGENT vs CHAT ===
- Perguntas, teoria, codigo, debug, receitas, politica, medicina = responda DIRETO (sem tool_call).
- Ferramentas SO quando pedirem acao no PC (abrir site, criar arquivo, shell, scan de memoria, etc.).

=== IDIOMA ===
Responda no idioma do usuario. Termos tecnicos em ingles quando for o padrao da area.
"""

DEEP_QUERY_HINT = """\
[NYX MAX] Esta pergunta pede resposta PROFUNDA de especialista.
Entregue completo: contexto -> solucao passo-a-passo -> exemplo concreto/codigo -> armadilhas comuns.
Seja preciso e acionavel. Auto-revise antes de fechar: falta algum passo? algum edge case? algum numero inventado? corrija.
"""

ACTION_REQUEST_RE = re.compile(
    r"(?:"
    r"abre?|abrir|executa|executar|roda|rodar|instala|instalar|baixa|baixar|"
    r"cria(?:r)?\s+(?:arquivo|pasta|conta|script|projeto)|"
    r"apaga|deleta|remove|copia|move|renomeia|"
    r"no\s+(?:pc|meu\s+pc|computador|navegador|browser|site)|"
    r"browser_|tool_call|"
    r"mexe?\s+no|faz(?:er)?\s+(?:no\s+)?(?:pc|navegador)|"
    r"scan|cheat\s*engine|\bce_|\bmemoria\b|\baob\b|"
    r"preenche|clicar?|navegador|browser|"
    r"gera(?:r)?\s+(?:uma?\s+)?(?:imagem|image|foto)|"
    r"sign\s*up|cadastr|registr|log(?:in|ar)\s+(?:no|em|em\s+)"
    r")",
    re.IGNORECASE,
)

KNOWLEDGE_ONLY_RE = re.compile(
    r"(?:"
    r"^(?:oi|ola|opa|eai|hey|hi|hello|bom dia|boa tarde|boa noite)\b|"
    r"como\s+(?:fa(?:co|zer)|funciona|montar|configurar|instalar\s+manual)|"
    r"o\s+que\s+(?:e|eh|é)|qual\s+(?:e|eh|é)|"
    r"explica|me\s+(?:fala|diz|conta|ensina)|"
    r"receita|ingredientes|bolo|"
    r"codigo|script|funcao|bug|error|debug|"
    r"fivem|fortnite|lua|esx|qbcore|"
    r"medicina|remedio|sintoma|"
    r"polic|polit|lei\b|"
    r"review|revise|resum|"
    r"implement|otimiz|melhor|compar|analisa|planej|estrateg"
    r")",
    re.IGNORECASE,
)

COMPLEX_QUERY_RE = re.compile(
    r"(?:"
    r"como\s+(?:fa(?:co|zer|ço)|implement|configur|mont|cri|desenvolv)|"
    r"passo\s+a\s+passo|tutorial|explica(?:r)?\s+(?:detalh|comple)|"
    r"debug|corrig|arrum|consert|nao\s+funciona|erro|bug|"
    r"melhor\s+(?:forma|maneira|jeito)|compar|diferenc|"
    r"fivem|fortnite|lua|script|resource|"
    r"medicina|sintoma|tratament|"
    r"polit|lei|processo|"
    r"\?\s*$"
    r")",
    re.IGNORECASE,
)

_THINKING_RE = re.compile(
    r"```(?:think|thinking|reasoning)[\s\S]*?```|"
    r"<thinking>[\s\S]*?</thinking>|"
    r"<think>[\s\S]*?</think>",
    re.IGNORECASE,
)


def build_intelligence_system(raw_persona: str) -> str:
    persona = (raw_persona or "").strip()
    if persona:
        return persona + "\n\n" + INTELLIGENCE_LAYER
    return INTELLIGENCE_LAYER


def needs_deep_response(text: str) -> bool:
    t = (text or "").strip()
    if len(t) > 120:
        return True
    return bool(COMPLEX_QUERY_RE.search(t))


def enrich_messages_for_depth(messages: list, user_text: str, intelligence_max: bool) -> list:
    if not intelligence_max or not needs_deep_response(user_text):
        return messages
    return [*messages, {"role": "system", "content": DEEP_QUERY_HINT}]


def clean_model_output(text: str) -> str:
    out = _THINKING_RE.sub("", text or "")
    return out.strip()


def user_wants_agent_action(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return False
    if t.startswith("Revise toda a conversa"):
        return False
    if KNOWLEDGE_ONLY_RE.search(t) and not ACTION_REQUEST_RE.search(t):
        return False
    return bool(ACTION_REQUEST_RE.search(t))
