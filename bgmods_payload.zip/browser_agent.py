"""NYX Browser — automacao de sites via Playwright (navegador visivel)."""

from __future__ import annotations

import os
import random
import re
import string
import sys
import time
from datetime import datetime
from pathlib import Path

from email_inbox import poll_verification_code

if getattr(sys, "frozen", False):
    os.environ.setdefault(
        "PLAYWRIGHT_BROWSERS_PATH",
        os.path.join(os.path.expanduser("~"), "AppData", "Local", "ms-playwright"),
    )

_session: "BrowserSession | None" = None


class BrowserSession:
    def __init__(self):
        self._playwright = None
        self._browser = None
        self._page = None
        self._workspace: Path | None = None
        self._last_elements: list[dict] = []

    def _ensure_playwright(self):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise RuntimeError(
                "playwright nao instalado. Rode INSTALAR_BROWSER.bat ou: "
                "pip install playwright && playwright install chromium"
            ) from exc
        return sync_playwright

    def ensure(self, workspace: Path):
        workspace.mkdir(parents=True, exist_ok=True)
        self._workspace = workspace
        if self._page is not None:
            return self._page

        sync_playwright = self._ensure_playwright()
        self._playwright = sync_playwright().start()
        self._browser = self._playwright.chromium.launch(headless=False)
        self._page = self._browser.new_page(viewport={"width": 1280, "height": 900})
        return self._page

    def close(self) -> str:
        try:
            if self._page:
                self._page.close()
            if self._browser:
                self._browser.close()
            if self._playwright:
                self._playwright.stop()
        except Exception:
            pass
        self._page = None
        self._browser = None
        self._playwright = None
        self._last_elements = []
        return "navegador fechado"

    def _shot_path(self, workspace: Path, prefix: str = "browser") -> Path:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        return workspace / f"{prefix}_{ts}.png"

    def navigate(self, workspace: Path, url: str) -> str:
        page = self.ensure(workspace)
        if not url.startswith(("http://", "https://")):
            url = "https://" + url.lstrip("/")
        page.goto(url, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(800)
        return f"navegou: {page.url}\ntitulo: {page.title()}"

    def snapshot(self, workspace: Path) -> str:
        page = self.ensure(workspace)
        shot = self._shot_path(workspace)
        page.screenshot(path=str(shot), full_page=False)

        elements = page.evaluate(
            """() => {
            const items = [];
            const sel = 'a, button, input, textarea, select, [role=button], canvas, [contenteditable=true], label, [onclick]';
            for (const el of document.querySelectorAll(sel)) {
                const rect = el.getBoundingClientRect();
                if (rect.width < 2 && rect.height < 2) continue;
                const style = window.getComputedStyle(el);
                if (style.visibility === 'hidden' || style.display === 'none') continue;
                const text = (
                    el.innerText || el.value || el.placeholder ||
                    el.getAttribute('aria-label') || el.title || ''
                ).trim().slice(0, 100);
                items.push({
                    index: items.length,
                    tag: el.tagName.toLowerCase(),
                    type: el.type || '',
                    text,
                    id: el.id || '',
                    name: el.name || '',
                    x: Math.round(rect.x + rect.width / 2),
                    y: Math.round(rect.y + rect.height / 2),
                    w: Math.round(rect.width),
                    h: Math.round(rect.height),
                });
                if (items.length >= 100) break;
            }
            return items;
        }"""
        )
        self._last_elements = elements or []

        lines = [
            f"url: {page.url}",
            f"titulo: {page.title()}",
            f"screenshot: {shot}",
            "",
            "elementos (use index, selector, text ou x/y):",
        ]
        for el in self._last_elements:
            label = el.get("text") or el.get("type") or el.get("tag")
            lines.append(
                f"  [{el['index']}] <{el['tag']}> \"{label}\" "
                f"@ ({el['x']},{el['y']}) {el['w']}x{el['h']} "
                f"id={el.get('id','')} name={el.get('name','')}"
            )
        if not self._last_elements:
            lines.append("  (nenhum elemento interativo detectado — use x/y ou browser_eval)")
        return "\n".join(lines)

    def _resolve_xy(self, args: dict) -> tuple[int, int] | None:
        if "x" in args and "y" in args:
            return int(args["x"]), int(args["y"])
        idx = args.get("index")
        if idx is not None and self._last_elements:
            i = int(idx)
            if 0 <= i < len(self._last_elements):
                el = self._last_elements[i]
                return el["x"], el["y"]
        return None

    def click(self, workspace: Path, args: dict) -> str:
        page = self.ensure(workspace)
        selector = (args.get("selector") or "").strip()
        text = (args.get("text") or "").strip()
        xy = self._resolve_xy(args)

        if selector:
            page.click(selector, timeout=10000)
            return f"clicou: {selector}"
        if text:
            page.get_by_text(text, exact=False).first.click(timeout=10000)
            return f"clicou texto: {text[:60]}"
        if xy:
            page.mouse.click(xy[0], xy[1])
            return f"clicou @ ({xy[0]},{xy[1]})"
        return "erro: informe selector, text, index ou x/y"

    def type_text(self, workspace: Path, args: dict) -> str:
        page = self.ensure(workspace)
        text = args.get("text", "")
        if text is None:
            text = ""
        selector = (args.get("selector") or "").strip()
        submit = bool(args.get("submit") or args.get("enter"))

        if selector:
            if args.get("clear"):
                page.fill(selector, str(text))
            else:
                page.type(selector, str(text), delay=30)
        else:
            idx = args.get("index")
            if idx is not None and self._last_elements:
                xy = self._resolve_xy({"index": idx})
                if xy:
                    page.mouse.click(xy[0], xy[1])
            page.keyboard.type(str(text), delay=30)

        if submit:
            page.keyboard.press("Enter")
        return f"digitou: {str(text)[:80]}"

    def press(self, workspace: Path, key: str) -> str:
        page = self.ensure(workspace)
        if not key:
            return "erro: key vazio"
        page.keyboard.press(key)
        return f"tecla: {key}"

    def scroll(self, workspace: Path, args: dict) -> str:
        page = self.ensure(workspace)
        delta_y = int(args.get("y", args.get("delta", 400)))
        direction = (args.get("direction") or "").lower()
        if direction == "up":
            delta_y = -abs(delta_y)
        elif direction == "down":
            delta_y = abs(delta_y)
        page.mouse.wheel(0, delta_y)
        return f"scroll y={delta_y}"

    def draw(self, workspace: Path, args: dict) -> str:
        page = self.ensure(workspace)
        points = args.get("points")
        if isinstance(points, str):
            import json
            try:
                points = json.loads(points.replace("'", '"'))
            except json.JSONDecodeError:
                return "erro: points invalido — use lista [[x,y],...]"

        if not points:
            fx, fy = args.get("from_x"), args.get("from_y")
            tx, ty = args.get("to_x"), args.get("to_y")
            if None not in (fx, fy, tx, ty):
                points = [[int(fx), int(fy)], [int(tx), int(ty)]]
            else:
                return "erro: informe points [[x,y],...] ou from_x/from_y/to_x/to_y"

        canvas_sel = (args.get("canvas") or args.get("selector") or "").strip()
        if canvas_sel:
            box = page.locator(canvas_sel).first.bounding_box()
            if not box:
                return f"erro: canvas nao encontrado: {canvas_sel}"
            offset_x, offset_y = box["x"], box["y"]
            points = [[int(p[0]) + offset_x, int(p[1]) + offset_y] for p in points]

        norm = []
        for p in points:
            if isinstance(p, (list, tuple)) and len(p) >= 2:
                norm.append((int(p[0]), int(p[1])))

        if len(norm) < 2:
            return "erro: precisa de pelo menos 2 pontos"

        page.mouse.move(norm[0][0], norm[0][1])
        page.mouse.down()
        for x, y in norm[1:]:
            page.mouse.move(x, y, steps=8)
        page.mouse.up()
        shot = self._shot_path(workspace, "draw")
        page.screenshot(path=str(shot))
        return f"desenhou {len(norm)} pontos. screenshot: {shot}"

    def wait(self, workspace: Path, ms: int) -> str:
        page = self.ensure(workspace)
        ms = max(0, min(int(ms), 30000))
        page.wait_for_timeout(ms)
        return f"esperou {ms}ms"

    def screenshot(self, workspace: Path, path: str | None = None) -> str:
        page = self.ensure(workspace)
        dest = Path(path) if path else self._shot_path(workspace)
        dest.parent.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(dest), full_page=False)
        return f"screenshot: {dest}"

    def eval_js(self, workspace: Path, script: str) -> str:
        page = self.ensure(workspace)
        if not script:
            return "erro: script vazio"
        result = page.evaluate(script)
        text = str(result)
        if len(text) > 4000:
            text = text[:4000] + "...(truncado)"
        return text or "(null)"

    def _try_fill(self, page, loc, value: str) -> bool:
        try:
            loc.first.scroll_into_view_if_needed(timeout=3000)
            loc.first.click(timeout=3000)
            loc.first.fill("", timeout=3000)
            loc.first.fill(value, timeout=3000)
            page.wait_for_timeout(400)
            try:
                actual = loc.first.input_value(timeout=2000)
                if actual and (actual == value or value in actual or actual in value):
                    return True
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _fill_by_strategies(self, page, strategies: list, value: str, name: str, filled: list) -> bool:
        for kind, target in strategies:
            try:
                if kind == "label":
                    loc = page.get_by_label(target, exact=False)
                elif kind == "label_exact":
                    loc = page.get_by_label(target, exact=True)
                elif kind == "placeholder":
                    loc = page.get_by_placeholder(target, exact=False)
                elif kind == "role":
                    loc = page.get_by_role(target[0], name=target[1])
                elif kind == "nth_text":
                    loc = page.locator(
                        'input:visible:not([type=password]):not([type=hidden]):not([type=checkbox])'
                    ).nth(target)
                else:
                    loc = page.locator(target)

                if loc.count() == 0:
                    continue
                if self._try_fill(page, loc, value):
                    filled.append(name)
                    return True
            except Exception:
                continue
        return False

    def _pick_dropdown_option(self, page, option_names: list[str]) -> bool:
        page.wait_for_timeout(350)
        for name in option_names:
            if not name:
                continue
            tries = [
                page.get_by_role("option", name=str(name), exact=True),
                page.get_by_role("option", name=str(name), exact=False),
                page.locator(f'[role="option"]:has-text("{name}")'),
                page.locator(f'li:has-text("{name}")'),
                page.get_by_text(str(name), exact=True),
            ]
            for loc in tries:
                try:
                    if loc.count() > 0:
                        loc.first.click(timeout=2500)
                        page.wait_for_timeout(250)
                        return True
                except Exception:
                    continue
        return False

    def _open_dob_trigger(self, page, labels: list[str]):
        for label in labels:
            tries = [
                page.get_by_role("combobox", name=label),
                page.locator(f'[aria-label="{label}"]'),
                page.locator(f'select[title="{label}"]'),
                page.locator(f'span:text-is("{label}")').locator("xpath=.."),
                page.locator(f'span:has-text("{label}")').first,
                page.get_by_text(label, exact=True),
            ]
            for loc in tries:
                try:
                    if loc.count() > 0:
                        loc.first.scroll_into_view_if_needed(timeout=2000)
                        loc.first.click(timeout=3000)
                        page.wait_for_timeout(200)
                        return True
                except Exception:
                    continue
        return False

    def _fill_instagram_dob(self, page, filled: list, day: int | None = None, month: int | None = None, year: int | None = None) -> str:
        day = day or random.randint(1, 28)
        month = month or random.randint(1, 12)
        year = year or random.randint(1990, 2002)
        months_pt = [
            "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
            "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
        ]
        month_pt = months_pt[month - 1]
        dob_str = f"{day:02d}/{month:02d}/{year}"

        # 1) Native select (inclui selects ocultos via JS)
        try:
            ok = page.evaluate(
                """([day, month, year, monthLabel]) => {
                const selects = Array.from(document.querySelectorAll('select'));
                if (selects.length < 3) return false;
                const fire = (el, val) => {
                    el.value = String(val);
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                };
                fire(selects[0], day);
                fire(selects[1], month);
                fire(selects[2], year);
                return true;
            }""",
                [day, month, year, month_pt],
            )
            if ok:
                page.wait_for_timeout(600)
                filled.append("data_nascimento")
                return dob_str
        except Exception:
            pass

        selects = page.locator("select")
        if selects.count() >= 3:
            try:
                for i, val in enumerate([str(day), str(month), str(year)]):
                    sel = selects.nth(i)
                    sel.click(force=True, timeout=3000)
                    page.wait_for_timeout(150)
                    try:
                        sel.select_option(value=val, force=True, timeout=3000)
                    except Exception:
                        if i == 1:
                            sel.select_option(label=month_pt, force=True, timeout=3000)
                        else:
                            raise
                    page.wait_for_timeout(200)
                filled.append("data_nascimento")
                return dob_str
            except Exception:
                pass

        # 2) Tres combobox (Instagram custom)
        combos = page.get_by_role("combobox")
        if combos.count() >= 3:
            try:
                combos.nth(0).click(timeout=3000)
                if self._pick_dropdown_option(page, [str(day), f"{day:02d}"]):
                    combos.nth(1).click(timeout=3000)
                    if self._pick_dropdown_option(page, [str(month), f"{month:02d}", month_pt]):
                        combos.nth(2).click(timeout=3000)
                        if self._pick_dropdown_option(page, [str(year)]):
                            filled.append("data_nascimento")
                            return dob_str
            except Exception:
                pass

        # 3) Clicar Dia / Mes / Ano e escolher opcao
        field_sets_list = [
            [
                ("Dia", [str(day), f"{day:02d}"]),
                ("Mês", [str(month), f"{month:02d}", month_pt]),
                ("Ano", [str(year)]),
            ],
            [
                ("Day", [str(day), f"{day:02d}"]),
                ("Month", [str(month), f"{month:02d}", month_pt]),
                ("Year", [str(year)]),
            ],
        ]

        for field_sets in field_sets_list:
            ok_all = True
            for label, options in field_sets:
                if not self._open_dob_trigger(page, [label]):
                    ok_all = False
                    break
                if not self._pick_dropdown_option(page, options):
                    ok_all = False
                    break
            if ok_all:
                filled.append("data_nascimento")
                return dob_str

        # 4) Achar 3 spans "Dia","Mes","Ano" dentro da secao data de nascimento
        try:
            section = page.locator('text=Data de nascimento').locator("xpath=ancestor::*[self::div or self::span][1]")
            if section.count() == 0:
                section = page.locator('text=Date of birth').locator("xpath=ancestor::*[self::div or self::span][1]")
            if section.count() > 0:
                triggers = section.first.locator("select, [role=combobox], span")
                if triggers.count() >= 3:
                    for i, options in enumerate([[str(day), f"{day:02d}"], [str(month), month_pt], [str(year)]]):
                        triggers.nth(i).click(timeout=3000)
                        if not self._pick_dropdown_option(page, options):
                            break
                    else:
                        filled.append("data_nascimento")
                        return dob_str
        except Exception:
            pass

        # 5) JS: clicar spans custom do Instagram
        try:
            ok = page.evaluate(
                """([day, month, year, monthLabel]) => {
                const labels = ['Dia', 'Mês', 'Mes', 'Ano', 'Day', 'Month', 'Year'];
                const spans = Array.from(document.querySelectorAll('span, div'))
                    .filter(el => labels.includes((el.textContent || '').trim()));
                const pick = (text) => {
                    const opts = Array.from(document.querySelectorAll('[role="option"], li, span, div'))
                        .filter(el => (el.textContent || '').trim() === String(text));
                    if (opts.length) { opts[0].click(); return true; }
                    return false;
                };
                const clickLabel = (lab) => {
                    const el = spans.find(s => (s.textContent || '').trim() === lab);
                    if (el) { el.click(); return true; }
                    return false;
                };
                if (!clickLabel('Dia') && !clickLabel('Day')) return false;
                if (!pick(day)) return false;
                if (!clickLabel('Mês') && !clickLabel('Mes') && !clickLabel('Month')) return false;
                if (!pick(month) && !pick(monthLabel)) return false;
                if (!clickLabel('Ano') && !clickLabel('Year')) return false;
                if (!pick(year)) return false;
                return true;
            }""",
                [day, month, year, month_pt],
            )
            if ok:
                page.wait_for_timeout(500)
                filled.append("data_nascimento")
                return dob_str
        except Exception:
            pass

        return ""

        return ""

    def _click_any_button(self, page, names: list[str], timeout: int = 4000) -> str | None:
        for name in names:
            try:
                btn = page.get_by_role("button", name=re.compile(re.escape(name), re.I))
                if btn.count() > 0:
                    btn.first.scroll_into_view_if_needed(timeout=3000)
                    btn.first.click(timeout=timeout)
                    page.wait_for_timeout(800)
                    return name
            except Exception:
                pass
            try:
                btn = page.get_by_text(name, exact=False)
                if btn.count() > 0:
                    btn.first.scroll_into_view_if_needed(timeout=3000)
                    btn.first.click(timeout=timeout)
                    page.wait_for_timeout(800)
                    return name
            except Exception:
                pass
        try:
            submit = page.locator('button[type="submit"]:visible')
            if submit.count() > 0:
                submit.first.scroll_into_view_if_needed(timeout=3000)
                submit.first.click(timeout=timeout)
                page.wait_for_timeout(800)
                return "submit"
        except Exception:
            pass
        return None

    def _wait_instagram_submit_ready(self, page, timeout_ms: int = 20000) -> bool:
        """Instagram so habilita Cadastre-se quando username validou e form ok."""
        deadline = time.time() + timeout_ms / 1000
        while time.time() < deadline:
            try:
                ready = page.evaluate(
                    """() => {
                    const btn = document.querySelector('button[type="submit"]');
                    if (!btn) return false;
                    const disabled = btn.disabled || btn.getAttribute('aria-disabled') === 'true';
                    if (!disabled) return true;
                    const user = document.querySelector('input[name="username"]');
                    const email = document.querySelector('input[name="emailOrPhone"]');
                    const pass = document.querySelector('input[name="password"]');
                    const name = document.querySelector('input[name="fullName"]');
                    if (!user?.value || !email?.value || !pass?.value || !name?.value) return false;
                    const selects = document.querySelectorAll('select');
                    if (selects.length >= 3) {
                        for (const s of selects) {
                            if (!s.value) return false;
                        }
                    }
                    return false;
                }"""
                )
                if ready:
                    return True
            except Exception:
                pass
            page.wait_for_timeout(500)
        return False

    def _click_instagram_submit(self, page) -> str | None:
        """Clica Cadastre-se — o ponto que falhava."""
        try:
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        except Exception:
            pass
        page.wait_for_timeout(600)

        self._wait_instagram_submit_ready(page, 20000)

        def try_enabled_submit():
            loc = page.locator('button[type="submit"]:not([disabled])')
            if loc.count() > 0:
                loc.first.scroll_into_view_if_needed(timeout=3000)
                loc.first.click(timeout=5000)
                return True
            return False

        def try_force_submit():
            loc = page.locator('button[type="submit"]')
            if loc.count() > 0:
                loc.first.scroll_into_view_if_needed(timeout=3000)
                loc.first.click(force=True, timeout=5000)
                return True
            return False

        def try_role_cadastre():
            for label in ("Cadastre-se", "Sign up", "Cadastrar"):
                btn = page.get_by_role("button", name=label)
                if btn.count() > 0:
                    btn.first.scroll_into_view_if_needed(timeout=3000)
                    btn.first.click(timeout=5000)
                    return True
            return False

        def try_div_button():
            loc = page.locator('div[role="button"]').filter(has_text=re.compile(r"Cadastre-se|Sign up", re.I))
            if loc.count() > 0:
                loc.first.scroll_into_view_if_needed(timeout=3000)
                loc.first.click(timeout=5000)
                return True
            return False

        def try_text_exact():
            page.get_by_text("Cadastre-se", exact=True).click(timeout=5000)
            return True

        def try_js_click():
            return page.evaluate(
                """() => {
                const all = [...document.querySelectorAll('button[type="submit"], div[role="button"], button')];
                const btn = all.find(el => /cadastre-se|sign up|cadastrar/i.test((el.innerText||el.textContent||'').trim()));
                if (!btn) return false;
                btn.scrollIntoView({block: 'center'});
                btn.removeAttribute('disabled');
                btn.setAttribute('aria-disabled', 'false');
                btn.click();
                return true;
            }"""
            )

        def try_coords_click():
            box = page.evaluate(
                """() => {
                const btn = document.querySelector('button[type="submit"]')
                    || [...document.querySelectorAll('div[role="button"]')].find(el => /cadastre/i.test(el.innerText||''));
                if (!btn) return null;
                const r = btn.getBoundingClientRect();
                return { x: r.x + r.width/2, y: r.y + r.height/2, w: r.width, h: r.height };
            }"""
            )
            if box and box.get("w", 0) > 0:
                page.mouse.click(box["x"], box["y"])
                return True
            return False

        for name, fn in [
            ("submit enabled", try_enabled_submit),
            ("submit force", try_force_submit),
            ("role Cadastre-se", try_role_cadastre),
            ("div role button", try_div_button),
            ("text Cadastre-se", try_text_exact),
            ("js click", try_js_click),
            ("mouse coords", try_coords_click),
        ]:
            try:
                if fn():
                    page.wait_for_timeout(1200)
                    return name
            except Exception:
                continue
        return None

    def _try_captcha(self, page) -> bool:
        try:
            frames = page.locator('iframe[src*="recaptcha"], iframe[title*="reCAPTCHA"]')
            if frames.count() > 0:
                fl = page.frame_locator('iframe[src*="recaptcha"], iframe[title*="reCAPTCHA"]').first
                fl.locator("#recaptcha-anchor, .recaptcha-checkbox-border").click(timeout=5000)
                page.wait_for_timeout(2500)
                return True
        except Exception:
            pass
        for txt in ("Não sou um robô", "I'm not a robot", "Confirmar que você"):
            try:
                page.get_by_text(txt, exact=False).first.click(timeout=2000)
                page.wait_for_timeout(2000)
                return True
            except Exception:
                pass
        return False

    def _fill_confirmation_code(self, page, code: str) -> bool:
        code = re.sub(r"\D", "", code)[:6]
        if len(code) < 6:
            return False

        selectors = [
            'input[name="email_confirmation_code"]',
            'input[autocomplete="one-time-code"]',
            'input[aria-label*="código" i]',
            'input[aria-label*="code" i]',
            'input[inputmode="numeric"]',
        ]
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if loc.count() > 0 and loc.is_visible(timeout=2000):
                    loc.click(timeout=2000)
                    loc.fill(code, timeout=3000)
                    page.wait_for_timeout(400)
                    return True
            except Exception:
                continue

        digits = page.locator('input[maxlength="1"]:visible, input[aria-label*="digit" i]:visible')
        if digits.count() >= 6:
            try:
                for i, ch in enumerate(code):
                    digits.nth(i).fill(ch, timeout=2000)
                page.wait_for_timeout(400)
                return True
            except Exception:
                pass

        try:
            page.keyboard.type(code, delay=80)
            return True
        except Exception:
            return False

    def _page_text(self, page) -> str:
        try:
            return (page.inner_text("body") or "").lower()
        except Exception:
            return ""

    def _instagram_step(self, page) -> str:
        txt = self._page_text(page)
        url = page.url.lower()

        if any(x in url for x in ("/accounts/onetap", "/?deoia=1")) or (
            "instagram.com" in url and "/accounts/" not in url and "/emailsignup" not in url
        ):
            if any(w in txt for w in ("página inicial", "home", "mensagens", "explorar", "search")):
                return "done"

        if any(w in txt for w in ("código de confirmação", "confirmation code", "insira o código", "enter the code")):
            return "verify_code"

        if any(w in txt for w in ("número de telefone", "phone number", "whatsapp")) and "código" not in txt:
            if page.locator('input[type="tel"]:visible').count() > 0:
                return "phone"

        if "recaptcha" in txt or "não sou um robô" in txt or "i'm not a robot" in txt:
            return "captcha"

        if any(w in txt for w in ("salvar informações", "save your login", "turn on notifications", "sincronize")):
            return "onboarding"

        if any(w in txt for w in ("adicionar foto", "add a profile photo", "sugeridos para você", "find friends")):
            return "onboarding"

        if any(w in txt for w in ("cadastre-se", "sign up", "comece a usar")):
            if page.locator('input[type="password"]:visible').count() > 0:
                return "signup_form"

        if any(w in txt for w in ("avançar", "next", "continuar", "confirm")):
            return "continue"

        return "unknown"

    def _run_post_submit(self, page, email: str, workspace: Path, log: list[str]) -> str:
        """Loop pos-cadastro: captcha, codigo email, onboarding ate conta pronta."""
        final_status = "incompleto"
        code_used = None

        for step_i in range(40):
            state = self._instagram_step(page)
            log.append(f"passo {step_i + 1}: {state}")
            shot = self._shot_path(workspace, f"ig_step_{step_i + 1}")
            try:
                page.screenshot(path=str(shot))
            except Exception:
                pass

            if state == "done":
                final_status = "conta criada"
                break

            if state == "captcha":
                if self._try_captcha(page):
                    log.append("captcha: clicado")
                page.wait_for_timeout(3000)
                continue

            if state == "verify_code":
                if not code_used:
                    log.append("email: buscando codigo no mailinator...")
                    code_used = poll_verification_code(email, timeout=90, interval=4)
                    if code_used:
                        log.append(f"email: codigo encontrado {code_used}")
                    else:
                        log.append("email: codigo NAO chegou no mailinator (90s)")
                if code_used:
                    if self._fill_confirmation_code(page, code_used):
                        log.append("codigo: preenchido")
                        clicked = self._click_any_button(page, [
                            "Avançar", "Next", "Confirmar", "Confirm", "Continuar", "Continue", "Enviar", "Submit",
                        ])
                        if clicked:
                            log.append(f"codigo: botao {clicked}")
                        page.wait_for_timeout(3000)
                continue

            if state == "phone":
                final_status = "bloqueado: instagram pediu telefone/SMS"
                log.append(final_status)
                break

            if state == "onboarding":
                clicked = self._click_any_button(page, [
                    "Agora não", "Not Now", "Pular", "Skip", "Ignorar", "Dismiss",
                    "Avançar", "Next", "Continuar", "Continue", "OK", "Concluir", "Done",
                ])
                if clicked:
                    log.append(f"onboarding: {clicked}")
                page.wait_for_timeout(2000)
                if "instagram.com" in page.url and "/accounts/emailsignup" not in page.url:
                    final_status = "conta criada (provavel)"
                continue

            if state == "continue":
                clicked = self._click_any_button(page, [
                    "Avançar", "Next", "Continuar", "Continue", "Confirmar", "Confirm", "OK",
                ])
                if clicked:
                    log.append(f"continue: {clicked}")
                page.wait_for_timeout(2500)
                continue

            if state == "signup_form":
                log.append("ainda no formulario — tentando cadastrar de novo")
                self._click_any_button(page, ["Cadastre-se", "Sign up", "Cadastrar"])
                page.wait_for_timeout(2500)
                continue

            self._try_captcha(page)
            page.wait_for_timeout(2000)

        return final_status

    def attempt_instagram_signup(self, workspace: Path, account: dict | None = None) -> str:
        page = self.ensure(workspace)
        log: list[str] = []

        nav = self.navigate(workspace, "https://www.instagram.com/accounts/emailsignup/")
        log.append(f"nav: {nav}")
        page.wait_for_timeout(2500)

        for label in (
            "Allow all cookies", "Permitir todos os cookies", "Accept All", "Aceitar tudo",
            "Permitir cookies essenciais e opcionais",
        ):
            try:
                page.get_by_role("button", name=label).click(timeout=1500)
                page.wait_for_timeout(600)
                break
            except Exception:
                pass

        if account:
            email = account.get("email", "")
            full_name = account.get("full_name", "")
            username = account.get("username", "")
            password = account.get("password", "")
            dob_day = account.get("dob_day")
            dob_month = account.get("dob_month")
            dob_year = account.get("dob_year")
        else:
            suffix = "".join(random.choices(string.ascii_lowercase + string.digits, k=6))
            email = f"nyx_test_{suffix}@mailinator.com"
            full_name = f"NYX Test {suffix}"
            username = f"nyx_{suffix}"
            password = f"Nyx!{suffix}9Aa"
            dob_day = dob_month = dob_year = None

        filled: list[str] = []
        missing: list[str] = []

        email_strategies = [
            ("label", "Número de celular ou email"),
            ("label", "Celular ou email"),
            ("label", "Mobile number or email"),
            ("placeholder", "Email"),
            ("selector", 'input[name="emailOrPhone"]'),
            ("selector", 'input[autocomplete="tel"]'),
            ("nth_text", 0),
        ]
        if not self._fill_by_strategies(page, email_strategies, email, "email", filled):
            missing.append("email")

        page.wait_for_timeout(400)

        pwd_strategies = [
            ("label", "Senha"),
            ("label", "Password"),
            ("selector", 'input[name="password"]'),
            ("selector", 'input[type="password"]'),
        ]
        if not self._fill_by_strategies(page, pwd_strategies, password, "senha", filled):
            missing.append("senha")

        page.wait_for_timeout(400)

        dob = self._fill_instagram_dob(page, filled, dob_day, dob_month, dob_year)
        if not dob:
            missing.append("data_nascimento")

        page.wait_for_timeout(400)

        name_strategies = [
            ("label_exact", "Nome"),
            ("label", "Nome completo"),
            ("label", "Full name"),
            ("selector", 'input[name="fullName"]'),
            ("nth_text", 1),
        ]
        if not self._fill_by_strategies(page, name_strategies, full_name, "nome", filled):
            missing.append("nome")

        page.wait_for_timeout(400)

        user_strategies = [
            ("label", "Nome de usuário"),
            ("label", "Username"),
            ("selector", 'input[name="username"]'),
            ("nth_text", 2),
        ]
        if not self._fill_by_strategies(page, user_strategies, username, "usuario", filled):
            missing.append("usuario")

        # Instagram valida username async — botao Cadastre-se so libera depois
        page.wait_for_timeout(2500)
        try:
            page.wait_for_function(
                """() => {
                const btn = document.querySelector('button[type="submit"]');
                return btn && !btn.disabled;
            }""",
                timeout=18000,
            )
        except Exception:
            pass

        page.wait_for_timeout(800)

        shot = self._shot_path(workspace, "instagram_signup")
        page.screenshot(path=str(shot))

        clicked = self._click_instagram_submit(page)
        log.append(f"cadastro: botao {'clicado (' + clicked + ')' if clicked else 'FALHOU — veja screenshot'}")

        page.wait_for_timeout(3500)
        self._try_captcha(page)
        page.wait_for_timeout(2000)

        shot2 = self._shot_path(workspace, "instagram_after_submit")
        page.screenshot(path=str(shot2))

        final_status = self._run_post_submit(page, email, workspace, log)

        shot3 = self._shot_path(workspace, "instagram_final")
        page.screenshot(path=str(shot3))

        creds_path = workspace / f"instagram_{username}.txt"
        creds_path.write_text(
            f"usuario: {username}\nemail: {email}\nsenha: {password}\nnome: {full_name}\nstatus: {final_status}\n",
            encoding="utf-8",
        )

        if not filled:
            snap = self.snapshot(workspace)
            return (
                "nao achei campos do formulario instagram. Pagina pode ter mudado.\n"
                f"{snap[:2000]}"
            )

        form_status = "ok" if not missing else f"faltou: {', '.join(missing)}"
        return (
            f"cadastro instagram automatico ({final_status}):\n"
            f"- email: {email} (codigo auto via mailinator)\n"
            f"- senha: {password}\n"
            f"- data nascimento: {dob or 'NAO PREENCHIDA'}\n"
            f"- nome: {full_name}\n"
            f"- usuario: {username}\n"
            f"- formulario: {form_status}\n"
            f"- campos ok: {', '.join(filled)}\n"
            f"- credenciais salvas: {creds_path}\n"
            f"- log: {' | '.join(log[-12:])}\n"
            f"- screenshots: {shot}, {shot2}, {shot3}\n"
            f"NOTA: se pedir SMS/telefone ou captcha de imagem, para ai. Email @mailinator.com recebe codigo automatico."
        )


def get_session() -> BrowserSession:
    global _session
    if _session is None:
        _session = BrowserSession()
    return _session


def close_browser() -> str:
    global _session
    if _session is None:
        return "navegador ja fechado"
    result = _session.close()
    _session = None
    return result


def attempt_instagram_signup(workspace: Path, on_step=None, account: dict | None = None) -> str:
    session = get_session()
    try:
        result = session.attempt_instagram_signup(workspace, account=account)
        if on_step:
            on_step("browser_instagram_signup", {}, result)
        return result
    except Exception as e:
        msg = f"erro instagram signup: {e}"
        if on_step:
            on_step("browser_instagram_signup", {}, msg)
        return msg


def execute_browser_tool(tool: str, args: dict, workspace: Path) -> str:
    tool = (tool or "").strip().lower()
    if tool == "browser_close":
        return close_browser()

    session = get_session()
    try:
        if tool == "browser_navigate":
            url = args.get("url", "")
            if not url:
                return "erro: url vazia"
            return session.navigate(workspace, url)

        if tool == "browser_snapshot":
            return session.snapshot(workspace)

        if tool == "browser_click":
            return session.click(workspace, args)

        if tool == "browser_type":
            return session.type_text(workspace, args)

        if tool == "browser_press":
            return session.press(workspace, args.get("key", ""))

        if tool == "browser_scroll":
            return session.scroll(workspace, args)

        if tool == "browser_draw":
            return session.draw(workspace, args)

        if tool == "browser_wait":
            ms = args.get("ms", args.get("seconds", 1))
            if isinstance(ms, (int, float)) and ms < 100:
                ms = int(float(ms) * 1000)
            return session.wait(workspace, int(ms))

        if tool == "browser_screenshot":
            return session.screenshot(workspace, args.get("path"))

        if tool == "browser_eval":
            return session.eval_js(workspace, args.get("script", ""))

        if tool == "browser_instagram_signup":
            return session.attempt_instagram_signup(workspace)

        return f"erro: tool browser desconhecida: {tool}"
    except Exception as e:
        msg = str(e)
        if "playwright" in msg.lower() or "Executable doesn't exist" in msg:
            return (
                "erro: playwright/chromium nao instalado. "
                "Rode INSTALAR_BROWSER.bat"
            )
        return f"erro browser: {e}"
