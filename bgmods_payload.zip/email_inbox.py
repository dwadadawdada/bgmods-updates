"""Leitura de codigos de verificacao — Mailinator publico."""

from __future__ import annotations

import re
import time

import requests

CODE_PATTERNS = [
    re.compile(r"(?:instagram|confirmation|confirmação|código|code)[^\d]{0,60}(\d{6})", re.I),
    re.compile(r"(\d{6})\s*(?:is your|é seu|is your Instagram)", re.I),
    re.compile(r"\b(\d{6})\b"),
]

MAILINATOR_BASE = "https://mailinator.com/api/v2/domains/public/inboxes"


def inbox_name(email: str) -> str:
    return email.split("@")[0].strip()


def _extract_code(text: str) -> str | None:
    if not text:
        return None
    for pat in CODE_PATTERNS:
        m = pat.search(text)
        if m:
            return m.group(1)
    return None


def _fetch_message_body(inbox: str, msg_id: str) -> str:
    url = f"{MAILINATOR_BASE}/{inbox}/messages/{msg_id}"
    try:
        resp = requests.get(url, timeout=20)
        if not resp.ok:
            return resp.text or ""
        data = resp.json()
        parts = []
        if isinstance(data, dict):
            parts.append(data.get("subject") or "")
            parts.append(str(data.get("body") or ""))
            parts.append(str(data.get("text") or ""))
            for part in data.get("parts") or []:
                if isinstance(part, dict):
                    parts.append(str(part.get("body") or ""))
        return "\n".join(parts)
    except Exception:
        return ""


def poll_verification_code(email: str, timeout: int = 120, interval: int = 4) -> str | None:
    """Busca codigo de 6 digitos no inbox publico do Mailinator."""
    inbox = inbox_name(email)
    if not inbox:
        return None

    deadline = time.time() + timeout
    seen_ids: set[str] = set()

    while time.time() < deadline:
        try:
            resp = requests.get(f"{MAILINATOR_BASE}/{inbox}", timeout=20)
            if resp.ok:
                data = resp.json()
                msgs = data.get("msgs") or data.get("messages") or []
                for msg in msgs:
                    if not isinstance(msg, dict):
                        continue
                    msg_id = str(msg.get("id") or msg.get("_id") or "")
                    if not msg_id or msg_id in seen_ids:
                        continue
                    seen_ids.add(msg_id)

                    subject = str(msg.get("subject") or "")
                    sender = str(msg.get("from") or msg.get("origfrom") or "").lower()
                    blob = subject + "\n" + _fetch_message_body(inbox, msg_id)

                    if "instagram" not in blob.lower() and "instagram" not in sender:
                        continue

                    code = _extract_code(blob)
                    if code:
                        return code
        except Exception:
            pass
        time.sleep(interval)

    return None
