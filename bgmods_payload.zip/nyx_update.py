"""Auto-update OTA — clientes recebem nova versao sem novo .bat."""

from __future__ import annotations

import io
import json
import urllib.error
import urllib.request
import zipfile
from pathlib import Path


def local_version(app_dir: Path) -> str:
    vf = app_dir / ".nyx_version"
    if vf.is_file():
        return vf.read_text(encoding="utf-8", errors="replace").strip()
    return "0"


def fetch_json(url: str, timeout: int = 20) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": "BG-MODS-IA-Update/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    if not isinstance(data, dict):
        raise ValueError("manifest invalido")
    return data


def download_bytes(url: str, timeout: int = 300) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "BG-MODS-IA-Update/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def apply_payload_zip(app_dir: Path, raw: bytes) -> None:
    app_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        for member in zf.namelist():
            if member.endswith("/"):
                continue
            dest = app_dir / member
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(member))


def check_and_apply(app_dir: Path, manifest_url: str) -> tuple[bool, str]:
    """
    Retorna (updated, message).
    manifest.json esperado:
      {"version": "202609051830", "zip_url": "https://.../bgmods_payload.zip"}
    """
    url = (manifest_url or "").strip()
    if not url:
        return False, ""

    try:
        manifest = fetch_json(url)
        remote_ver = str(manifest.get("version", "")).strip()
        zip_url = str(manifest.get("zip_url", "")).strip()
        if not remote_ver or not zip_url:
            return False, "manifest incompleto"

        current = local_version(app_dir)
        if remote_ver <= current:
            return False, ""

        payload = download_bytes(zip_url)
        apply_payload_zip(app_dir, payload)
        (app_dir / ".nyx_version").write_text(remote_ver + "\n", encoding="utf-8")
        return True, f"atualizado para {remote_ver}"
    except urllib.error.URLError as exc:
        return False, f"update offline: {exc.reason}"
    except Exception as exc:
        return False, f"update falhou: {exc}"
