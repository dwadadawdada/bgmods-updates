"""Entry-point do BG MODS IA — ativa o cofre e sobe o app.

Roda os modulos cifrados (.bgc) via bg_vault. Se os .bgc nao existirem
(build sem criptografia / dev), cai no import normal do nyx_app.py.
"""

from __future__ import annotations

import bg_vault

bg_vault.install()

import nyx_app

if __name__ == "__main__":
    nyx_app.main()
