"""Cliente MCP para Cheat Engine (miscusi-peek/cheatengine-mcp-bridge)."""

from __future__ import annotations

import asyncio
import sys
import threading
from contextlib import AsyncExitStack
from pathlib import Path
from typing import Any

_worker_lock = threading.Lock()
_worker: "CEMCPWorker | None" = None
_worker_script: str | None = None


def default_bridge_script(app_dir: Path) -> Path:
    return app_dir / "cheatengine-mcp-bridge" / "MCP_Server" / "mcp_cheatengine.py"


def resolve_bridge_script(config: dict | None, app_dir: Path) -> Path:
    cfg = config or {}
    raw = (cfg.get("ce_mcp_script") or "").strip()
    if raw:
        path = Path(raw)
        if not path.is_absolute():
            path = app_dir / path
        return path
    return default_bridge_script(app_dir)


def ce_mcp_enabled(config: dict | None) -> bool:
    return bool((config or {}).get("ce_mcp_enabled", False))


def _format_tool_result(result) -> str:
    parts: list[str] = []
    for block in result.content or []:
        text = getattr(block, "text", None)
        if text:
            parts.append(text)
        elif isinstance(block, dict) and block.get("text"):
            parts.append(str(block["text"]))
    if parts:
        return "\n".join(parts)
    if getattr(result, "isError", False):
        return "erro: resposta vazia do CE MCP"
    return str(result)


class CEMCPWorker:
    def __init__(self, script_path: Path):
        self.script_path = str(script_path)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._session = None
        self._stack: AsyncExitStack | None = None
        self._ready = threading.Event()
        self._error: str | None = None
        self._call_lock = threading.Lock()

    def start(self, timeout: float = 45) -> str | None:
        self._thread = threading.Thread(target=self._run, name="ce-mcp-worker", daemon=True)
        self._thread.start()
        if not self._ready.wait(timeout=timeout):
            return "erro: timeout ao iniciar CE MCP (pip install mcp pywin32?)"
        return self._error

    def _run(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._connect())
        except Exception as exc:
            self._error = f"erro ce_mcp connect: {exc}"
        finally:
            self._ready.set()
        if self._error:
            return
        self._loop.run_forever()

    async def _connect(self) -> None:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        if not Path(self.script_path).is_file():
            raise FileNotFoundError(f"script nao encontrado: {self.script_path}")

        self._stack = AsyncExitStack()
        params = StdioServerParameters(
            command=sys.executable,
            args=[self.script_path],
        )
        read, write = await self._stack.enter_async_context(stdio_client(params))
        self._session = await self._stack.enter_async_context(ClientSession(read, write))
        await self._session.initialize()

    def _run_coro(self, coro, timeout: float = 120):
        if not self._loop or not self._session:
            raise RuntimeError("CE MCP nao conectado")
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=timeout)

    def call_tool(self, name: str, arguments: dict | None = None, timeout: float = 120) -> str:
        with self._call_lock:
            async def _call():
                result = await self._session.call_tool(name, arguments or {})
                return _format_tool_result(result)

            return self._run_coro(_call(), timeout=timeout)

    def list_tools(self, timeout: float = 60) -> str:
        with self._call_lock:
            async def _list():
                result = await self._session.list_tools()
                names = sorted(t.name for t in result.tools)
                if not names:
                    return "(nenhuma tool listada)"
                return "\n".join(names)

            return self._run_coro(_list(), timeout=timeout)

    def shutdown(self) -> None:
        if not self._loop:
            return

        async def _close():
            if self._stack:
                await self._stack.aclose()

        try:
            self._run_coro(_close(), timeout=10)
        except Exception:
            pass
        self._loop.call_soon_threadsafe(self._loop.stop)


def _get_worker(script_path: Path) -> tuple[CEMCPWorker | None, str | None]:
    global _worker, _worker_script

    script = str(script_path.resolve())
    with _worker_lock:
        if _worker and _worker_script == script and _worker._session and not _worker._error:
            return _worker, None

        if _worker:
            _worker.shutdown()
            _worker = None
            _worker_script = None

        worker = CEMCPWorker(script_path)
        err = worker.start()
        if err:
            worker.shutdown()
            return None, err

        _worker = worker
        _worker_script = script
        return _worker, None


def close_ce_mcp() -> None:
    global _worker, _worker_script
    with _worker_lock:
        if _worker:
            _worker.shutdown()
        _worker = None
        _worker_script = None


def _missing_deps_hint(exc: Exception) -> str:
    msg = str(exc).lower()
    if "no module named 'mcp'" in msg or "no module named \"mcp\"" in msg:
        return "erro: pacote mcp nao instalado — rode INSTALAR_CE_MCP.bat"
    if "pywin32" in msg or "win32file" in msg:
        return "erro: pywin32 nao instalado — rode INSTALAR_CE_MCP.bat"
    return f"erro ce_mcp: {exc}"


def call_ce_tool(
    tool_name: str,
    arguments: dict | None,
    config: dict | None,
    app_dir: Path,
    timeout: float = 120,
) -> str:
    if not ce_mcp_enabled(config):
        return "erro: CE MCP desligado no config (ce_mcp_enabled=false)"

    script_path = resolve_bridge_script(config, app_dir)
    if not script_path.is_file():
        return (
            f"erro: bridge nao encontrado em {script_path}\n"
            "rode INSTALAR_CE_MCP.bat e carregue ce_mcp_bridge.lua no Cheat Engine"
        )

    try:
        worker, err = _get_worker(script_path)
        if err:
            return err
        assert worker is not None
        return worker.call_tool(tool_name, arguments or {}, timeout=timeout)
    except ImportError as exc:
        return _missing_deps_hint(exc)
    except Exception as exc:
        close_ce_mcp()
        return _missing_deps_hint(exc)


def list_ce_tools(config: dict | None, app_dir: Path) -> str:
    if not ce_mcp_enabled(config):
        return "erro: CE MCP desligado no config"

    script_path = resolve_bridge_script(config, app_dir)
    if not script_path.is_file():
        return f"erro: bridge nao encontrado: {script_path}"

    try:
        worker, err = _get_worker(script_path)
        if err:
            return err
        assert worker is not None
        return worker.list_tools()
    except ImportError as exc:
        return _missing_deps_hint(exc)
    except Exception as exc:
        close_ce_mcp()
        return _missing_deps_hint(exc)


CE_AGENT_LAYER = """\
Cheat Engine (memoria / reverse) — requer CE aberto com ce_mcp_bridge.lua carregado:
- ce_ping: sem args — testa conexao com o bridge
- ce_list_tools: sem args — lista todas as tools MCP do CE (~180)
- ce_call: args.tool (nome exato), args.arguments (objeto JSON opcional) — chama qualquer tool CE
Atalhos comuns:
- ce_open_process: args.process_id_or_name — anexar processo
- ce_read_memory: args.address, args.size (opcional, default 256)
- ce_read_integer: args.address, args.type (byte/word/dword/qword/float/double)
- ce_scan_all: args.value, args.type (opcional dword)
- ce_aob_scan: args.pattern, args.protection (opcional +X), args.limit (opcional)
- ce_get_process_info: sem args
- ce_enum_modules: args.offset, args.limit (opcionais)
Fluxo tipico: ce_ping -> ce_open_process -> ce_scan_all / ce_aob_scan -> ce_read_integer
No Cheat Engine: desative "Query memory region routines" nas settings (README do bridge).
"""


CE_SHORTCUTS: dict[str, str] = {
    "ce_ping": "ping",
    "ce_open_process": "open_process",
    "ce_read_memory": "read_memory",
    "ce_read_integer": "read_integer",
    "ce_read_string": "read_string",
    "ce_scan_all": "scan_all",
    "ce_aob_scan": "aob_scan",
    "ce_get_process_info": "get_process_info",
    "ce_enum_modules": "enum_modules",
    "ce_get_symbol_address": "get_symbol_address",
    "ce_write_integer": "write_integer",
    "ce_disassemble": "disassemble",
}


def execute_ce_agent_tool(tool: str, args: dict, config: dict | None, app_dir: Path) -> str:
    tool = (tool or "").strip().lower()
    args = dict(args or {})

    if tool == "ce_list_tools":
        return list_ce_tools(config, app_dir)

    if tool == "ce_call":
        name = (args.get("tool") or args.get("name") or "").strip()
        if not name:
            return "erro: ce_call precisa args.tool com nome da tool MCP"
        arguments = args.get("arguments") or args.get("args") or {}
        if not isinstance(arguments, dict):
            return "erro: ce_call args.arguments deve ser objeto JSON"
        return call_ce_tool(name, arguments, config, app_dir)

    mapped = CE_SHORTCUTS.get(tool)
    if mapped:
        return call_ce_tool(mapped, args, config, app_dir)

    return f"erro: tool CE desconhecida: {tool}"


def build_ce_agent_layer(config: dict | None) -> str:
    if not ce_mcp_enabled(config):
        return ""
    return "\n\n" + CE_AGENT_LAYER.strip()
