"""KeyAuth client for NYX — license key only, no os._exit."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any

import requests

try:
    from discord_interactions import verify_key
except ImportError:
    verify_key = None

KEYAUTH_URL = "https://keyauth.win/api/1.3/"
KEYAUTH_PUBLIC_KEY = "5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b"


class KeyAuthError(Exception):
    pass


@dataclass
class LicenseInfo:
    username: str
    expires_unix: int
    subscription: str
    license_key: str

    @property
    def expires_at(self) -> datetime:
        return datetime.fromtimestamp(int(self.expires_unix), tz=timezone.utc)

    @property
    def is_expired(self) -> bool:
        return datetime.now(timezone.utc) >= self.expires_at

    def expires_label(self) -> str:
        local = self.expires_at.astimezone()
        return local.strftime("%d/%m/%Y %H:%M")


def file_checksum() -> str:
    target = Path_for_checksum()
    data = target.read_bytes()
    return hashlib.md5(data).hexdigest()


def Path_for_checksum():
    from pathlib import Path
    if getattr(sys, "frozen", False):
        return Path(sys.executable)
    return Path(__file__).resolve().parent / "nyx_app.py"


def get_hwid() -> str:
    if platform.system() != "Windows":
        return platform.node() or "unknown"
    import win32security  # type: ignore

    user = __import__("os").getlogin()
    sid = win32security.LookupAccountName(None, user)[0]
    return win32security.ConvertSidToStringSid(sid)


class KeyAuthClient:
    def __init__(self, name: str, ownerid: str, version: str, hash_to_check: str = ""):
        if len(ownerid) != 10:
            raise KeyAuthError("ownerid invalido — copie do painel KeyAuth (10 caracteres)")
        self.name = name.strip()
        self.ownerid = ownerid.strip()
        self.version = version.strip()
        self.hash_to_check = hash_to_check or file_checksum()
        self.sessionid = ""
        self.initialized = False
        self._user: dict[str, Any] | None = None

    def init(self) -> None:
        if self.initialized:
            return
        data = self._request({
            "type": "init",
            "ver": self.version,
            "hash": self.hash_to_check,
            "name": self.name,
            "ownerid": self.ownerid,
        })
        if data.get("message") == "invalidver":
            dl = data.get("download") or ""
            raise KeyAuthError(
                "Versao desatualizada no KeyAuth."
                + (f" Baixe: {dl}" if dl else " Atualize version no keyauth.json.")
            )
        if not data.get("success"):
            raise KeyAuthError(data.get("message") or "init falhou")
        self.sessionid = data["sessionid"]
        self.initialized = True

    def license(self, key: str) -> LicenseInfo:
        self._ensure_init()
        key = (key or "").strip()
        if not key:
            raise KeyAuthError("license key vazia")
        data = self._request({
            "type": "license",
            "key": key,
            "hwid": get_hwid(),
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid,
        })
        if not data.get("success"):
            raise KeyAuthError(data.get("message") or "license invalida")
        self._user = data["info"]
        info = self._parse_user(self._user, key)
        if info.is_expired:
            raise KeyAuthError("SUA KEY FOI EXPIRADA")
        return info

    def check_session(self) -> bool:
        self._ensure_init()
        data = self._request({
            "type": "check",
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid,
        })
        return bool(data.get("success"))

    def current_license(self, key: str) -> LicenseInfo | None:
        if not self._user:
            return None
        info = self._parse_user(self._user, key)
        if info.is_expired:
            return None
        return info

    def _parse_user(self, data: dict, key: str) -> LicenseInfo:
        subs = data.get("subscriptions") or []
        if not subs:
            raise KeyAuthError("subscription ausente na resposta KeyAuth")
        sub = subs[0]
        return LicenseInfo(
            username=data.get("username") or "user",
            expires_unix=int(sub.get("expiry") or 0),
            subscription=sub.get("subscription") or "default",
            license_key=key,
        )

    def _ensure_init(self) -> None:
        if not self.initialized:
            self.init()

    def _request(self, payload: dict) -> dict:
        if verify_key is None and payload.get("type") not in ("log", "file"):
            raise KeyAuthError(
                "pacote discord-interactions nao instalado. Rode INSTALAR.bat ou: pip install discord-interactions"
            )
        try:
            resp = requests.post(KEYAUTH_URL, data=payload, timeout=15)
        except requests.RequestException as exc:
            raise KeyAuthError(f"sem conexao com KeyAuth: {exc}") from exc

        if payload.get("type") in ("log", "file"):
            try:
                return json.loads(resp.text)
            except json.JSONDecodeError:
                raise KeyAuthError("resposta KeyAuth invalida") from None

        signature = resp.headers.get("x-signature-ed25519")
        timestamp = resp.headers.get("x-signature-timestamp")
        if not signature or not timestamp:
            raise KeyAuthError("resposta KeyAuth sem assinatura")

        server_time = datetime.fromtimestamp(int(timestamp), timezone.utc)
        if datetime.now(timezone.utc) - server_time > timedelta(seconds=25):
            raise KeyAuthError("relógio do PC dessincronizado — ajuste data/hora")

        if not verify_key(resp.text.encode("utf-8"), signature, timestamp, KEYAUTH_PUBLIC_KEY):
            raise KeyAuthError("assinatura KeyAuth invalida (sessao expirada ou resposta adulterada)")

        try:
            return json.loads(resp.text)
        except json.JSONDecodeError as exc:
            raise KeyAuthError("JSON KeyAuth invalido") from exc
