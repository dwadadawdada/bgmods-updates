"""NYX Agent — ferramentas pra IA agir no PC do usuario."""

import glob as glob_module
import json
import os
import re
import shutil
import subprocess
import urllib.parse
from pathlib import Path

import requests

from browser_agent import close_browser, execute_browser_tool, attempt_instagram_signup
from ce_mcp_client import CE_SHORTCUTS, build_ce_agent_layer, close_ce_mcp, execute_ce_agent_tool

BROWSER_TOOLS = {
    "browser_navigate", "browser_snapshot", "browser_click", "browser_type",
    "browser_press", "browser_scroll", "browser_draw", "browser_wait",
    "browser_screenshot", "browser_eval", "browser_close", "browser_instagram_signup",
}

AGENT_LAYER = """\
Voce controla o PC Windows do usuario via ferramentas REAIS. O usuario AUTORIZOU acoes no PC dele.

REGRA — ANTI-ALUCINACAO:
- PROIBIDO dizer que fez algo no PC/site sem tool_call + resultado real
- Se precisa agir (criar pasta, arquivo, shell, browser, CE): use tool_call AGORA
- Se for so pergunta/teoria: responda direto SEM tool_call

Formato:
<tool_call>
{"tool": "NOME", "args": {...}}
</tool_call>

Ferramentas:

Arquivos (qualquer path do PC se o usuario pedir): read_file, write_file, append_file, delete_path, copy_path, move_path, create_dir, list_dir, search_files, open_path
Shell: run_shell, list_processes, pip_install
Rede: download_file
Navegador: browser_navigate, browser_snapshot, browser_click, browser_type, browser_press, browser_scroll, browser_screenshot, browser_eval, browser_close, browser_wait, browser_draw
Imagens: generate_image
Cheat Engine: ce_ping, ce_scan_all, ce_call, etc.

Fluxo browser: browser_navigate -> browser_snapshot -> browser_click/type
Responda ao usuario SOMENTE depois dos resultados reais das ferramentas.
"""

CE_TOOLS = {"ce_ping", "ce_list_tools", "ce_call", *CE_SHORTCUTS.keys()}

TOOL_TAG_RE = re.compile(r"<tool_call>(.*?)</tool_call>", re.DOTALL | re.IGNORECASE)

IMAGE_REQUEST_RE = re.compile(
    r"(?:^|\s)(?:gera|gerar|cria|criar|faz|fazer|draw|generate|manda|mostra)\s+(?:uma?\s+)?(?:imagem|image|foto|picture)\b",
    re.IGNORECASE,
)

BROWSER_ACTION_RE = re.compile(
    r"(?:criar|cria|fazer|faz|abrir|entrar|acessar|ir\s+no|ir\s+em|cadastr|registr|sign\s*up|log(?:in|ar)|"
    r"conta|site|instagram|insta|gmail|google|facebook|tiktok|twitter|desenhar\s+no|navegador|browser|"
    r"preenche|clicar?|formul)",
    re.IGNORECASE,
)

SITE_URLS = {
    "instagram": "https://www.instagram.com/accounts/emailsignup/",
    "insta": "https://www.instagram.com/accounts/emailsignup/",
    "gmail": "https://accounts.google.com/signup",
    "google": "https://accounts.google.com/signup",
    "facebook": "https://www.facebook.com/r.php",
    "tiktok": "https://www.tiktok.com/signup",
    "twitter": "https://x.com/i/flow/signup",
    "x.com": "https://x.com/i/flow/signup",
}

JSON_TOOL_RE = re.compile(
    r'\{[^{}]*"(?:tool|name|action)"\s*:\s*"[^"]+"[^{}]*\}',
    re.DOTALL | re.IGNORECASE,
)

FORCE_TOOL_NUDGE = (
    "ERRO: voce respondeu sem usar ferramentas. PROIBIDO inventar resultados.\n"
    "O usuario pediu ACAO REAL no PC ou site. Use AGORA o formato:\n"
    "<tool_call>\n{\"tool\": \"NOME\", \"args\": {...}}\n</tool_call>\n"
    "Nao diga que fez algo. Use a proxima ferramenta baseada nos resultados anteriores."
)


def user_wants_image(user_text: str) -> bool:
    if not user_text or not user_text.strip():
        return False
    return bool(IMAGE_REQUEST_RE.search(user_text.strip()))


def user_wants_browser(user_text: str) -> bool:
    if not user_text or not user_text.strip():
        return False
    text = user_text.strip()
    if user_wants_image(text):
        return False
    if re.search(r"https?://", text, re.IGNORECASE):
        return True
    return bool(BROWSER_ACTION_RE.search(text))


def extract_browser_url(user_text: str) -> str | None:
    if not user_text:
        return None
    m = re.search(r"(https?://[^\s\"']+)", user_text, re.IGNORECASE)
    if m:
        return m.group(1).rstrip(".,)")
    lower = user_text.lower()
    for key, url in SITE_URLS.items():
        if key in lower:
            return url
    return None


def bootstrap_browser(user_text: str, workspace: Path, on_step=None) -> list[tuple[str, dict, str]]:
    """Abre o site automaticamente quando o usuario pede acao no browser."""
    url = extract_browser_url(user_text)
    if not url:
        return []

    results: list[tuple[str, dict, str]] = []
    nav_args = {"url": url}
    nav_result = execute_browser_tool("browser_navigate", nav_args, workspace)
    results.append(("browser_navigate", nav_args, nav_result))
    if on_step:
        on_step("browser_navigate", nav_args, nav_result)

    if nav_result.startswith("erro"):
        return results

    wait_result = execute_browser_tool("browser_wait", {"ms": 1500}, workspace)
    results.append(("browser_wait", {"ms": 1500}, wait_result))
    if on_step:
        on_step("browser_wait", {"ms": 1500}, wait_result)

    lower = user_text.lower()
    if "instagram" in lower or "insta" in lower:
        if any(w in lower for w in ("conta", "cadastr", "criar", "cria", "registr", "signup", "sign up")):
            ig_result = attempt_instagram_signup(workspace, on_step=on_step)
            results.append(("browser_instagram_signup", {}, ig_result))
            return results

    snap_result = execute_browser_tool("browser_snapshot", {}, workspace)
    results.append(("browser_snapshot", {}, snap_result))
    if on_step:
        on_step("browser_snapshot", {}, snap_result)

    return results


def normalize_call(call: dict) -> dict:
    if not isinstance(call, dict):
        return {"tool": "", "args": {}}
    tool = call.get("tool") or call.get("name") or call.get("action") or ""
    args = call.get("args")
    if not isinstance(args, dict):
        args = {}
    for key in ("prompt", "command", "url", "path", "content", "description", "text",
                "src", "dest", "pattern", "package", "cwd", "selector", "key", "script",
                "canvas", "from_x", "from_y", "to_x", "to_y", "index", "points", "ms"):
        if key in call and call[key] and key not in args:
            mapped = "prompt" if key in ("description", "text") else key
            args[mapped] = call[key]
    return {"tool": str(tool).strip().lower(), "args": args}


def _parse_json_obj(raw: str) -> dict | None:
    for attempt in (raw, raw.replace("'", '"')):
        try:
            data = json.loads(attempt)
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            continue
    return None


def parse_tool_calls(text: str) -> list[dict]:
    calls = []
    seen = set()

    def add_call(parsed: dict | None):
        if not parsed:
            return
        norm = normalize_call(parsed)
        if not norm["tool"]:
            return
        key = (norm["tool"], json.dumps(norm["args"], sort_keys=True))
        if key in seen:
            return
        seen.add(key)
        calls.append(norm)

    for match in TOOL_TAG_RE.finditer(text):
        add_call(_parse_json_obj(match.group(1).strip()))

    if calls:
        return calls

    for match in JSON_TOOL_RE.finditer(text):
        add_call(_parse_json_obj(match.group(0)))

    if calls:
        return calls

    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            add_call(_parse_json_obj(line))

    return calls


def strip_tool_calls(text: str) -> str:
    return TOOL_TAG_RE.sub("", text).strip()


def extract_image_prompt(user_text: str) -> str | None:
    if not user_wants_image(user_text):
        return None
    patterns = [
        r"(?:gera|gerar|cria|criar|faz|fazer|draw|generate|manda|mostra)\s+(?:uma?\s+)?(?:imagem|image|foto|picture)\s+(?:de\s+|com\s+|about\s+|:)?\s*(.+)",
    ]
    for pat in patterns:
        m = re.search(pat, user_text.strip(), re.IGNORECASE | re.DOTALL)
        if m:
            prompt = m.group(1).strip().strip('"').strip("'")
            if prompt and len(prompt) > 2:
                return prompt
    return None


def _default_path(workspace: Path, filename: str) -> str:
    workspace.mkdir(parents=True, exist_ok=True)
    return str(workspace / filename)


def _resolve_path(path_str: str, workspace: Path) -> Path:
    p = Path(path_str)
    if not p.is_absolute():
        p = workspace / p
    return p


def _truncate(text: str, limit: int = 8000) -> str:
    text = (text or "").strip() or "(sem output)"
    if len(text) > limit:
        return text[:limit] + "\n...(truncado)"
    return text


def execute_tool(
    tool: str,
    args: dict,
    workspace: Path,
    user_context: str = "",
    allow_image: bool = False,
    ce_config: dict | None = None,
    app_dir: Path | None = None,
) -> str:
    tool = (tool or "").strip().lower()
    args = dict(args or {})

    if tool in CE_TOOLS:
        if not app_dir:
            return "erro: CE MCP indisponivel (app_dir)"
        return execute_ce_agent_tool(tool, args, ce_config, app_dir)

    if tool == "generate_image":
        if not allow_image:
            return "ignorado: usuario nao pediu imagem nesta mensagem"
        prompt = (args.get("prompt") or "").strip()
        if not prompt:
            prompt = extract_image_prompt(user_context) or ""
        if not prompt:
            return "erro: prompt vazio — peca ao usuario descrever a imagem"
        args["prompt"] = prompt
        if not args.get("path"):
            safe = re.sub(r"[^\w\-]+", "_", prompt[:40]).strip("_") or "generated"
            args["path"] = _default_path(workspace, f"{safe}.png")

    try:
        if tool in BROWSER_TOOLS:
            return execute_browser_tool(tool, args, workspace)

        if tool == "run_shell":
            command = args.get("command", "")
            if not command:
                return "erro: command vazio"
            cwd = args.get("cwd")
            if cwd:
                cwd = str(_resolve_path(cwd, workspace))
            else:
                cwd = str(Path.home())
            proc = subprocess.run(
                command, shell=True, capture_output=True, text=True,
                cwd=cwd, timeout=300, encoding="utf-8", errors="replace",
            )
            out = ((proc.stdout or "") + (proc.stderr or "")).strip()
            return f"exit={proc.returncode}\n{_truncate(out)}"

        if tool == "download_file":
            url = args.get("url", "")
            if not url:
                return "erro: url vazia"
            dest = Path(args.get("path") or _default_path(workspace, "download.bin"))
            dest.parent.mkdir(parents=True, exist_ok=True)
            with requests.get(url, stream=True, timeout=300) as r:
                r.raise_for_status()
                with open(dest, "wb") as f:
                    for chunk in r.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
            return f"baixado: {dest} ({dest.stat().st_size} bytes)"

        if tool == "write_file":
            path = args.get("path")
            if not path:
                return "erro: path vazio"
            dest = _resolve_path(path, workspace)
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(args.get("content", ""), encoding="utf-8", errors="surrogatepass")
            return f"escrito: {dest} ({dest.stat().st_size} bytes)"

        if tool == "append_file":
            path = args.get("path")
            if not path:
                return "erro: path vazio"
            dest = _resolve_path(path, workspace)
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "a", encoding="utf-8", errors="surrogatepass") as f:
                f.write(args.get("content", ""))
            return f"append: {dest} ({dest.stat().st_size} bytes)"

        if tool == "read_file":
            path = args.get("path")
            if not path:
                return "erro: path vazio"
            dest = _resolve_path(path, workspace)
            if not dest.exists():
                return f"erro: nao existe: {dest}"
            if dest.is_dir():
                return f"erro: {dest} e uma pasta, use list_dir"
            text = dest.read_text(encoding="utf-8", errors="replace")
            return text[:12000] + ("\n...(truncado)" if len(text) > 12000 else "")

        if tool == "delete_path":
            path = args.get("path")
            if not path:
                return "erro: path vazio"
            dest = _resolve_path(path, workspace)
            if not dest.exists():
                return f"erro: nao existe: {dest}"
            if dest.is_dir():
                shutil.rmtree(dest)
            else:
                dest.unlink()
            return f"apagado: {dest}"

        if tool == "copy_path":
            src = args.get("src")
            dest_str = args.get("dest")
            if not src or not dest_str:
                return "erro: src e dest obrigatorios"
            src_p = _resolve_path(src, workspace)
            dest_p = _resolve_path(dest_str, workspace)
            if not src_p.exists():
                return f"erro: origem nao existe: {src_p}"
            dest_p.parent.mkdir(parents=True, exist_ok=True)
            if src_p.is_dir():
                shutil.copytree(src_p, dest_p, dirs_exist_ok=True)
            else:
                shutil.copy2(src_p, dest_p)
            return f"copiado: {src_p} -> {dest_p}"

        if tool == "move_path":
            src = args.get("src")
            dest_str = args.get("dest")
            if not src or not dest_str:
                return "erro: src e dest obrigatorios"
            src_p = _resolve_path(src, workspace)
            dest_p = _resolve_path(dest_str, workspace)
            if not src_p.exists():
                return f"erro: origem nao existe: {src_p}"
            dest_p.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(src_p), str(dest_p))
            return f"movido: {src_p} -> {dest_p}"

        if tool == "create_dir":
            path = args.get("path")
            if not path:
                return "erro: path vazio"
            dest = _resolve_path(path, workspace)
            dest.mkdir(parents=True, exist_ok=True)
            return f"pasta criada: {dest}"

        if tool == "list_dir":
            dest = _resolve_path(args.get("path", str(workspace)), workspace)
            if not dest.exists():
                return f"erro: nao existe: {dest}"
            if not dest.is_dir():
                return f"erro: {dest} nao e pasta"
            items = []
            for item in sorted(dest.iterdir())[:300]:
                kind = "DIR" if item.is_dir() else "FILE"
                size = item.stat().st_size if item.is_file() else 0
                items.append(f"{kind}\t{size}\t{item.name}")
            return "\n".join(items) or "(vazio)"

        if tool == "search_files":
            base = args.get("path", str(Path.home()))
            pattern = args.get("pattern", "*")
            base_p = _resolve_path(base, workspace)
            if not base_p.exists():
                return f"erro: nao existe: {base_p}"
            search_pat = str(base_p / pattern)
            matches = glob_module.glob(search_pat, recursive=True)[:200]
            if not matches:
                return f"nenhum resultado para {pattern} em {base_p}"
            lines = []
            for m in matches:
                p = Path(m)
                kind = "DIR" if p.is_dir() else "FILE"
                size = p.stat().st_size if p.is_file() else 0
                lines.append(f"{kind}\t{size}\t{m}")
            return "\n".join(lines)

        if tool == "list_processes":
            proc = subprocess.run(
                "tasklist /FO CSV /NH", shell=True, capture_output=True,
                text=True, timeout=30, encoding="utf-8", errors="replace",
            )
            out = (proc.stdout or "").strip()
            lines = out.splitlines()[:100]
            return _truncate("\n".join(lines), 6000)

        if tool == "pip_install":
            package = (args.get("package") or "").strip()
            if not package:
                return "erro: package vazio"
            proc = subprocess.run(
                f'pip install "{package}"', shell=True, capture_output=True,
                text=True, timeout=600, encoding="utf-8", errors="replace",
            )
            out = ((proc.stdout or "") + (proc.stderr or "")).strip()
            return f"exit={proc.returncode}\n{_truncate(out)}"

        if tool == "generate_image":
            prompt = args["prompt"]
            dest = Path(args["path"])
            dest.parent.mkdir(parents=True, exist_ok=True)
            url = (
                "https://image.pollinations.ai/prompt/"
                + urllib.parse.quote(prompt)
                + "?width=1024&height=1024&nologo=true"
            )
            resp = requests.get(url, timeout=300)
            resp.raise_for_status()
            dest.write_bytes(resp.content)
            return f"imagem gerada: {dest} ({dest.stat().st_size} bytes)"

        if tool == "open_path":
            path = args.get("path")
            if not path:
                return "erro: path vazio"
            dest = _resolve_path(path, workspace)
            if not dest.exists():
                return f"erro: nao existe: {dest}"
            os.startfile(str(dest))  # noqa: S606
            return f"aberto: {dest}"

        return f"erro: tool desconhecida: {tool}"

    except subprocess.TimeoutExpired:
        return "erro: comando excedeu timeout"
    except Exception as e:
        return f"erro: {e}"


def try_direct_image(user_text: str, workspace: Path) -> str | None:
    if not user_wants_image(user_text):
        return None
    prompt = extract_image_prompt(user_text)
    if not prompt:
        return None
    result = execute_tool("generate_image", {"prompt": prompt}, workspace, user_text, allow_image=True)
    if result.startswith("erro") or result.startswith("ignorado"):
        return None
    img_path = result.split(": ", 1)[-1].split(" (")[0]
    open_result = execute_tool("open_path", {"path": img_path}, workspace, user_text, allow_image=True)
    return f"Pronto — imagem gerada.\n{result}\n{open_result}"


def _last_user_text(messages: list) -> str:
    for msg in reversed(messages):
        if msg.get("role") == "user":
            content = msg.get("content", "")
            if isinstance(content, str) and content.strip():
                if content.startswith("Resultados das ferramentas:"):
                    continue
                return content.strip()
    return ""


def close_browser_session() -> str:
    from browser_agent import close_browser
    return close_browser()


def run_agent_loop(
    chat_fn,
    messages: list,
    workspace: Path,
    max_steps: int = 16,
    on_step=None,
    user_context: str = "",
    ce_config: dict | None = None,
    app_dir: Path | None = None,
    cancel_check=None,
) -> str:
    ctx = user_context or _last_user_text(messages)
    allow_image = user_wants_image(ctx)
    wants_browser = user_wants_browser(ctx)
    image_done = False
    nudge_count = 0
    max_nudges = 3

    if allow_image:
        direct = try_direct_image(ctx, workspace)
        if direct:
            if on_step:
                on_step("direct", {"prompt": extract_image_prompt(ctx)}, direct)
            return direct

    working = list(messages)
    last_reply = ""
    boot_results: list[tuple[str, dict, str]] = []
    direct_browser_reply: str | None = None

    if wants_browser:
        boot_results = bootstrap_browser(ctx, workspace, on_step=on_step)
        if boot_results:
            for tool, _args, result in boot_results:
                if tool == "browser_instagram_signup" and (
                    "usuario:" in result or "cadastro instagram automatico" in result
                ):
                    direct_browser_reply = result
            lines = [f"[{tool}] {result}" for tool, _args, result in boot_results]
            working.append({
                "role": "user",
                "content": (
                    "Bootstrap automatico — navegador aberto:\n"
                    + "\n".join(lines)
                    + "\n\nContinue com browser_click/browser_type pra completar o pedido. "
                    "Use tool_call. Nao invente dados."
                ),
            })

    for step in range(max_steps):
        if cancel_check and cancel_check():
            return strip_tool_calls(last_reply) + "\n\n[cancelado pelo operador]"
        if on_step:
            on_step("__think__", {"passo": step + 1, "max": max_steps}, f"planejando acao {step + 1}/{max_steps}")
        last_reply = chat_fn(working)
        calls = parse_tool_calls(last_reply)

        if not calls:
            if wants_browser and nudge_count < max_nudges:
                nudge_count += 1
                working.append({"role": "assistant", "content": last_reply})
                working.append({"role": "user", "content": FORCE_TOOL_NUDGE})
                continue

            cleaned = strip_tool_calls(last_reply) or last_reply
            if direct_browser_reply:
                return direct_browser_reply
            if wants_browser and boot_results:
                return (
                    cleaned
                    + "\n\n[AVISO: a IA nao conseguiu usar ferramentas. "
                    "O navegador FOI aberto — veja a janela do Chromium na tela. "
                    "Rode INSTALAR_BROWSER.bat se deu erro de playwright. "
                    "Tente pedir: 'preenche o formulario que esta aberto']"
                )
            return cleaned

        working.append({"role": "assistant", "content": last_reply})
        results = []

        if on_step:
            tools = ", ".join(normalize_call(c)["tool"] for c in calls)
            on_step("__plan__", {"count": len(calls)}, f"executando: {tools}")

        for call in calls:
            norm = normalize_call(call)
            tool = norm["tool"]

            if tool == "generate_image":
                if not allow_image or image_done:
                    result = "ignorado: imagem ja gerada ou nao pedida"
                else:
                    result = execute_tool(
                        tool, norm["args"], workspace, ctx, allow_image=True,
                        ce_config=ce_config, app_dir=app_dir,
                    )
                    if "imagem gerada" in result:
                        image_done = True
            else:
                result = execute_tool(
                    tool, norm["args"], workspace, ctx, allow_image=False,
                    ce_config=ce_config, app_dir=app_dir,
                )

            if on_step:
                on_step(tool, norm["args"], result)
            results.append(f"[{tool}] {result}")

        working.append({
            "role": "user",
            "content": "Resultados das ferramentas:\n" + "\n".join(results) + "\n\nContinue. Se terminou, responda ao usuario com base NOS RESULTADOS REAIS.",
        })
        nudge_count = 0

    return strip_tool_calls(last_reply) + "\n\n(max agent steps atingido — veja janela do navegador se abriu)"
