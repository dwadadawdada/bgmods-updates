"""Gate de licenca KeyAuth — login UI + sessao local."""

from __future__ import annotations

import json
from pathlib import Path

import customtkinter as ctk

from keyauth_nyx import KeyAuthClient, KeyAuthError, LicenseInfo

LICENSE_STORE_NAME = "license.json"
APP_BRAND = "BG MODS IA"


def keyauth_config_path(app_dir: Path) -> Path:
    return app_dir / "keyauth.json"


def license_store_path(user_data_dir: Path) -> Path:
    return user_data_dir / LICENSE_STORE_NAME


def load_keyauth_app_config(app_dir: Path) -> dict:
    path = keyauth_config_path(app_dir)
    defaults = {"enabled": False, "name": "", "ownerid": "", "version": "1.0", "update_manifest_url": ""}
    if not path.is_file():
        return defaults
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {**defaults, **data}
    except json.JSONDecodeError:
        pass
    return defaults


def load_saved_license(user_data_dir: Path) -> dict | None:
    path = license_store_path(user_data_dir)
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def save_license(user_data_dir: Path, info: LicenseInfo) -> None:
    user_data_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "license_key": info.license_key,
        "username": info.username,
        "expires_unix": info.expires_unix,
        "subscription": info.subscription,
    }
    license_store_path(user_data_dir).write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def clear_saved_license(user_data_dir: Path) -> None:
    path = license_store_path(user_data_dir)
    if path.is_file():
        path.unlink()


def build_client(app_dir: Path) -> tuple[KeyAuthClient | None, dict]:
    cfg = load_keyauth_app_config(app_dir)
    if not cfg.get("enabled"):
        return None, cfg
    if not cfg.get("name") or not cfg.get("ownerid"):
        raise KeyAuthError(
            "keyauth.json incompleto. Preencha name e ownerid do painel KeyAuth."
        )
    client = KeyAuthClient(cfg["name"], cfg["ownerid"], cfg.get("version") or "1.0")
    client.init()
    return client, cfg


def _is_expired_error(exc: KeyAuthError | str) -> bool:
    msg = str(exc).lower()
    return "expir" in msg or "expired" in msg


def show_expired_dialog(parent: ctk.CTk | ctk.CTkToplevel | None = None) -> None:
    """Modal de key expirada — estilo underground."""
    owns_root = parent is None
    if owns_root:
        win = ctk.CTk()
    else:
        win = ctk.CTkToplevel(parent)
        win.transient(parent)
        win.grab_set()

    win.title(f"{APP_BRAND} — ACCESS DENIED")
    win.geometry("520x340")
    win.configure(fg_color="#080004")
    win.resizable(False, False)
    win.attributes("-topmost", True)

    ctk.CTkLabel(
        win, text="╔══════════════════════════════════════╗",
        font=ctk.CTkFont(family="Consolas", size=10),
        text_color="#660022",
    ).pack(pady=(18, 0))

    ctk.CTkLabel(
        win, text="SUA KEY FOI EXPIRADA",
        font=ctk.CTkFont(family="Consolas", size=22, weight="bold"),
        text_color="#ff0033",
    ).pack(pady=(10, 4))

    ctk.CTkLabel(
        win, text="[ ACCESS REVOKED // LICENSE TERMINATED ]",
        font=ctk.CTkFont(family="Consolas", size=11),
        text_color="#aa2244",
    ).pack(pady=(0, 8))

    ctk.CTkLabel(
        win, text="╚══════════════════════════════════════╝",
        font=ctk.CTkFont(family="Consolas", size=10),
        text_color="#660022",
    ).pack()

    ctk.CTkLabel(
        win,
        text="Sessao encerrada.\nCompre uma nova key para continuar usando o BG MODS IA.",
        font=ctk.CTkFont(family="Consolas", size=11),
        text_color="#886677",
        justify="center",
    ).pack(pady=(16, 8))

    ctk.CTkLabel(
        win, text=">> trace.wipe() // channel.sealed // hwid.locked",
        font=ctk.CTkFont(family="Consolas", size=9),
        text_color="#442233",
    ).pack(pady=(4, 0))

    def close():
        try:
            win.grab_release()
        except Exception:
            pass
        win.destroy()

    ctk.CTkButton(
        win, text="ENTENDI", command=close, width=140, height=34,
        fg_color="#1a0008", border_color="#ff0033", border_width=1,
        hover_color="#330011", text_color="#ff4466",
        font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
    ).pack(pady=20)

    win.protocol("WM_DELETE_WINDOW", close)
    if owns_root:
        win.mainloop()
    else:
        win.wait_window()


class LicenseGate:
    """Valida licenca antes de abrir o app."""

    def __init__(self, app_dir: Path, user_data_dir: Path):
        self.app_dir = app_dir
        self.user_data_dir = user_data_dir
        self.client: KeyAuthClient | None = None
        self.info: LicenseInfo | None = None
        self.enabled = False

    def authenticate(self, root: ctk.CTk | None = None) -> LicenseInfo | None:
        cfg = load_keyauth_app_config(self.app_dir)
        if not cfg.get("enabled"):
            self.enabled = False
            return None

        self.enabled = True
        self.client, _ = build_client(self.app_dir)

        saved = load_saved_license(self.user_data_dir)
        if saved and saved.get("license_key"):
            key = saved["license_key"]
            exp = int(saved.get("expires_unix") or 0)
            if exp > 0:
                from datetime import datetime, timezone
                if datetime.now(timezone.utc).timestamp() >= exp:
                    show_expired_dialog()
                    clear_saved_license(self.user_data_dir)
                    return self._login_dialog(root)
            try:
                self.info = self.client.license(key)
                save_license(self.user_data_dir, self.info)
                return self.info
            except KeyAuthError as exc:
                if _is_expired_error(exc):
                    show_expired_dialog()
                clear_saved_license(self.user_data_dir)

        return self._login_dialog(root)

    def _login_dialog(self, root: ctk.CTk | None) -> LicenseInfo | None:
        _ = root
        win = ctk.CTk()
        win.title(f"{APP_BRAND} — AUTH GATE")
        win.geometry("500x360")
        win.configure(fg_color="#030803")
        win.resizable(False, False)
        win.attributes("-topmost", True)
        win.after(200, lambda: win.attributes("-topmost", False))

        result: dict[str, LicenseInfo | None] = {"info": None}

        ctk.CTkLabel(
            win, text="[ UNAUTHORIZED CHANNEL // KEY REQUIRED ]",
            font=ctk.CTkFont(family="Consolas", size=9),
            text_color="#664444",
        ).pack(pady=(16, 4))

        ctk.CTkLabel(
            win, text=f"> {APP_BRAND}",
            font=ctk.CTkFont(family="Consolas", size=18, weight="bold"),
            text_color="#00ff41",
        ).pack(pady=(0, 2))

        ctk.CTkLabel(
            win, text="shadow.auth // license.verify()",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color="#335533",
        ).pack(pady=(0, 14))

        ctk.CTkLabel(
            win, text="Cole sua license key (salva automaticamente)",
            font=ctk.CTkFont(family="Consolas", size=11),
            text_color="#5a8a5a",
        ).pack(pady=(0, 8))

        entry = ctk.CTkEntry(
            win, width=400, height=38,
            fg_color="#050a05", border_color="#1a3a1a", text_color="#b8ffb8",
            placeholder_text="XXXX-XXXX-XXXX-XXXX",
            font=ctk.CTkFont(family="Consolas", size=12),
            show="*",
        )
        entry.pack(pady=4)
        entry.focus_set()

        show_key = {"visible": False}

        def toggle_key():
            show_key["visible"] = not show_key["visible"]
            entry.configure(show="" if show_key["visible"] else "*")
            eye_btn.configure(text="OCULTAR" if show_key["visible"] else "MOSTRAR")

        eye_btn = ctk.CTkButton(
            win, text="MOSTRAR", command=toggle_key, width=90, height=24,
            fg_color="transparent", border_color="#1a2a1a", border_width=1,
            hover_color="#0a120a", text_color="#557755",
            font=ctk.CTkFont(family="Consolas", size=9),
        )
        eye_btn.pack(pady=(2, 0))

        status = ctk.CTkLabel(
            win, text="",
            font=ctk.CTkFont(family="Consolas", size=10),
            text_color="#ff6666",
        )
        status.pack(pady=(8, 0))

        ctk.CTkLabel(
            win, text=">> key gravada localmente apos ativacao",
            font=ctk.CTkFont(family="Consolas", size=8),
            text_color="#223322",
        ).pack(pady=(4, 0))

        def activate():
            key = entry.get().strip()
            if not self.client:
                status.configure(text="KeyAuth nao inicializado", text_color="#ff6666")
                return
            try:
                info = self.client.license(key)
                save_license(self.user_data_dir, info)
                self.info = info
                result["info"] = info
                win.quit()
            except KeyAuthError as exc:
                if _is_expired_error(exc):
                    status.configure(text="SUA KEY FOI EXPIRADA", text_color="#ff0033")
                else:
                    status.configure(text=str(exc), text_color="#ff6666")

        def on_close():
            win.quit()

        entry.bind("<Return>", lambda _e: activate())

        row = ctk.CTkFrame(win, fg_color="transparent")
        row.pack(pady=16)
        ctk.CTkButton(
            row, text="ATIVAR", command=activate, width=120,
            fg_color="#0a1a0a", border_color="#00ff41", border_width=1,
            hover_color="#0d2a0d", text_color="#00ff41",
            font=ctk.CTkFont(family="Consolas", size=11, weight="bold"),
        ).pack(side="left", padx=6)
        ctk.CTkButton(
            row, text="SAIR", command=on_close, width=80,
            fg_color="transparent", border_color="#3a1a1a", border_width=1,
            hover_color="#1a0d0d", text_color="#ff6666",
            font=ctk.CTkFont(family="Consolas", size=11),
        ).pack(side="left", padx=6)

        win.protocol("WM_DELETE_WINDOW", on_close)
        win.mainloop()
        try:
            win.destroy()
        except Exception:
            pass
        return result["info"]

    def try_reactivate(self) -> LicenseInfo | None:
        """Apos expiracao em runtime — pede nova key sem reiniciar o app."""
        if not self.enabled:
            return None
        clear_saved_license(self.user_data_dir)
        if not self.client:
            self.client, _ = build_client(self.app_dir)
        return self._login_dialog(None)

    def verify_active(self) -> LicenseInfo:
        if not self.enabled:
            raise KeyAuthError("licenciamento desligado")
        if not self.client or not self.info:
            raise KeyAuthError("nao autenticado")
        if self.info.is_expired:
            raise KeyAuthError("SUA KEY FOI EXPIRADA")
        if not self.client.check_session():
            # revalida com a key salva
            saved = load_saved_license(self.user_data_dir)
            key = (saved or {}).get("license_key") or self.info.license_key
            self.info = self.client.license(key)
            save_license(self.user_data_dir, self.info)
        return self.info

    def logout(self) -> None:
        clear_saved_license(self.user_data_dir)
        self.info = None
