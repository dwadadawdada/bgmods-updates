"""bg_vault — carrega os modulos do BG MODS IA a partir de blobs cifrados (.bgc).

Objetivo: o codigo-fonte NAO fica em .py legivel na maquina do cliente.
Cada modulo protegido vira <nome>.bgc (cifrado). Este loader descriptografa
em memoria e executa — nada de fonte em claro no disco.

Limite honesto: a chave vive aqui (necessario pra rodar no cliente). Isso barra
copia casual/revenda, nao um reverse-engineer dedicado. Somado ao KeyAuth, para
o roubo comum.
"""

from __future__ import annotations

import hashlib
import importlib.abc
import importlib.util
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
EXT = ".bgc"

# passphrase montada em pedacos (nao aparece inteira numa linha)
_P = ("bg" "mods" "-ia" ":: ") + ("v4ult" "//") + ("sh4dow" "-k3y")
_SALT = b"BGMODS-IA::static-salt::do-not-change"

# modulos servidos por este loader (preenchido pelo build; fallback abaixo)
PROTECTED = {
    "nyx_app",
    "agent_tools",
    "browser_agent",
    "ce_mcp_client",
    "intelligence_layer",
    "email_inbox",
    "keyauth_nyx",
    "nyx_license",
    "nyx_update",
}


def _key() -> bytes:
    return hashlib.pbkdf2_hmac("sha256", _P.encode("utf-8"), _SALT, 120_000)


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest()
        counter += 1
    return bytes(out[:length])


def encrypt(data: bytes) -> bytes:
    import os

    key = _key()
    nonce = os.urandom(16)
    ks = _keystream(key, nonce, len(data))
    ct = bytes(a ^ b for a, b in zip(data, ks))
    mac = hashlib.sha256(key + nonce + ct).digest()[:16]
    return b"BGC1" + nonce + mac + ct


def decrypt(blob: bytes) -> bytes:
    if blob[:4] != b"BGC1":
        raise ValueError("blob invalido")
    nonce = blob[4:20]
    mac = blob[20:36]
    ct = blob[36:]
    key = _key()
    if hashlib.sha256(key + nonce + ct).digest()[:16] != mac:
        raise ValueError("integridade falhou")
    ks = _keystream(key, nonce, len(ct))
    return bytes(a ^ b for a, b in zip(ct, ks))


class _VaultLoader(importlib.abc.Loader):
    def __init__(self, origin: str):
        self.origin = origin

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        raw = Path(self.origin).read_bytes()
        source = decrypt(raw)
        code = compile(source, self.origin, "exec")
        module.__file__ = self.origin
        exec(code, module.__dict__)


class _VaultFinder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname not in PROTECTED:
            return None
        blob = APP_DIR / (fullname + EXT)
        if not blob.is_file():
            return None
        origin = str(blob)
        return importlib.util.spec_from_loader(
            fullname, _VaultLoader(origin), origin=origin
        )


def install() -> None:
    if not any(isinstance(f, _VaultFinder) for f in sys.meta_path):
        sys.meta_path.insert(0, _VaultFinder())
